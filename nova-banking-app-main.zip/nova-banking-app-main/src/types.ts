export type ScreenType =
  | 'login'
  | 'home'
  | 'cards'
  | 'payments'
  | 'insights'
  | 'profile'
  | 'transaction-detail';

export interface Transaction {
  id: string;
  merchant: string;
  category: string;
  categoryType: 'food' | 'electronics' | 'income' | 'transport' | 'groceries' | 'entertainment' | 'shopping' | 'utilities' | 'other' | 'bills';
  subCategory?: string;
  amount: number;
  type: 'debit' | 'credit';
  date: string;
  fullDate: string;
  time: string;
  branch?: string;
  address?: string;
  reference: string;
  paymentMethod: string;
  status: 'Completed' | 'Pending';
  speed: 'Instant' | 'Standard';
  rewardsStars?: number;
  rewardNote?: string;
  terminal?: string;
  posType?: string;
  iconName: string;
  iconBg: string;
  iconColor: string;
  receiptImage?: string;
  recognized?: boolean;
}

export interface CardInfo {
  id: string;
  type: 'virtual' | 'physical';
  bankName: string;
  lastFour: string;
  cardholder: string;
  expires: string;
  cvv: string;
  isFrozen: boolean;
  spendingUsed: number;
  spendingLimit: number;
}

export interface UpcomingBill {
  id: string;
  biller: string;
  amount: number;
  accountSuffix: string;
  dueDate: string;
  dueNote: string;
  isOverdue: boolean;
  category: string;
  icon: string;
  paid: boolean;
}

export interface UserProfile {
  name: string;
  firstName: string;
  email: string;
  tier: string;
  avatarUrl: string;
  accountsConnected: number;
  biometricEnabled: boolean;
  darkMode: boolean;
  balance?: number;
  totalSpentThisMonth?: number;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  time: string;
  read: boolean;
  type: 'security' | 'payment' | 'reward' | 'system';
}
