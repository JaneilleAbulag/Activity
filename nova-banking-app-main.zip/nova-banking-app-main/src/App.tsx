import React, { useState } from 'react';
import {
  ScreenType,
  Transaction,
  CardInfo,
  UpcomingBill,
  UserProfile,
  NotificationItem,
} from './types';
import {
  MOCK_USER,
  MOCK_TRANSACTIONS,
  MOCK_CARDS,
  MOCK_BILLS,
  MOCK_NOTIFICATIONS,
} from './data/mockData';
import { TopBar } from './components/TopBar';
import { BottomNav } from './components/BottomNav';
import { LoginScreen } from './components/LoginScreen';
import { HomeScreen } from './components/HomeScreen';
import { CardsScreen } from './components/CardsScreen';
import { PaymentsScreen } from './components/PaymentsScreen';
import { InsightsScreen } from './components/InsightsScreen';
import { ProfileScreen } from './components/ProfileScreen';
import { TransactionDetailScreen } from './components/TransactionDetailScreen';
import { SendMoneyModal } from './components/SendMoneyModal';
import { TopUpModal } from './components/TopUpModal';
import { SplitBillModal } from './components/SplitBillModal';
import { NotificationsSheet } from './components/NotificationsSheet';
import { AddCardModal } from './components/AddCardModal';

export function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(true);
  const [currentScreen, setCurrentScreen] = useState<ScreenType>('home');
  const [previousScreen, setPreviousScreen] = useState<ScreenType>('home');

  // Application State
  const [user, setUser] = useState<UserProfile>(MOCK_USER);
  const [transactions, setTransactions] = useState<Transaction[]>(MOCK_TRANSACTIONS);
  const [cards, setCards] = useState<CardInfo[]>(MOCK_CARDS);
  const [bills, setBills] = useState<UpcomingBill[]>(MOCK_BILLS);
  const [notifications, setNotifications] = useState<NotificationItem[]>(MOCK_NOTIFICATIONS);

  const userBalance = user.balance ?? 8450.25;

  // Selected Transaction for Detail View
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(
    MOCK_TRANSACTIONS[0]
  );

  // Toast Notification State
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Modal Visibility States
  const [sendModalOpen, setSendModalOpen] = useState(false);
  const [topUpModalOpen, setTopUpModalOpen] = useState(false);
  const [splitBillModalOpen, setSplitBillModalOpen] = useState(false);
  const [splitTransaction, setSplitTransaction] = useState<Transaction | null>(null);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [addCardModalOpen, setAddCardModalOpen] = useState(false);

  const showToast = (message: string) => {
    setToastMessage(message);
    setTimeout(() => {
      setToastMessage((current) => (current === message ? null : current));
    }, 3200);
  };

  const handleNavigate = (screen: ScreenType) => {
    if (screen !== currentScreen) {
      setPreviousScreen(currentScreen);
      setCurrentScreen(screen);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleSelectTransaction = (tx: Transaction) => {
    setSelectedTransaction(tx);
    setPreviousScreen(currentScreen);
    setCurrentScreen('transaction-detail');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBack = () => {
    setCurrentScreen(previousScreen === 'transaction-detail' ? 'home' : previousScreen);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Money Operations
  const handleSendMoney = (recipient: string, amount: number, note: string) => {
    setUser((prev) => ({
      ...prev,
      balance: Math.max(0, (prev.balance ?? 8450.25) - amount),
      totalSpentThisMonth: (prev.totalSpentThisMonth ?? 1240.50) + amount,
    }));

    const newTx: Transaction = {
      id: `tx-${Date.now()}`,
      merchant: recipient,
      category: 'Transfer',
      amount,
      type: 'debit',
      date: 'Today',
      time: 'Just now',
      fullDate: `Today, ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`,
      iconName: 'send',
      iconBg: 'bg-[#eff4ff]',
      iconColor: 'text-[#0b1f3a]',
      status: 'Completed',
      speed: 'Instant',
      paymentMethod: 'Checking (•••• 4821)',
      reference: `TXN-${Math.floor(10000 + Math.random() * 90000)}-NV`,
      categoryType: 'other',
    };

    setTransactions((prev) => [newTx, ...prev]);
    showToast(`Sent $${amount.toFixed(2)} to ${recipient} • ${note || 'Transfer'}`);
  };

  const handleTopUp = (amount: number, source: string) => {
    setUser((prev) => ({
      ...prev,
      balance: (prev.balance ?? 8450.25) + amount,
    }));

    const newTx: Transaction = {
      id: `tx-${Date.now()}`,
      merchant: `Deposit from ${source.split(' ')[0]}`,
      category: 'Deposit',
      amount,
      type: 'credit',
      date: 'Today',
      time: 'Just now',
      fullDate: `Today, ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`,
      iconName: 'account_balance',
      iconBg: 'bg-[#6df5e1]/30',
      iconColor: 'text-[#006f64]',
      status: 'Completed',
      speed: 'Instant',
      paymentMethod: 'Checking (•••• 4821)',
      reference: `DEP-${Math.floor(10000 + Math.random() * 90000)}-NV`,
      categoryType: 'income',
    };

    setTransactions((prev) => [newTx, ...prev]);
    showToast(`Successfully deposited $${amount.toFixed(2)} from ${source}`);
  };

  const handlePayBill = (billId: string) => {
    const bill = bills.find((b) => b.id === billId);
    if (!bill) return;

    setUser((prev) => ({
      ...prev,
      balance: Math.max(0, (prev.balance ?? 8450.25) - bill.amount),
      totalSpentThisMonth: (prev.totalSpentThisMonth ?? 1240.50) + bill.amount,
    }));

    const newTx: Transaction = {
      id: `tx-${Date.now()}`,
      merchant: bill.biller,
      category: 'Utilities',
      subCategory: bill.category,
      amount: bill.amount,
      type: 'debit',
      date: 'Today',
      time: 'Just now',
      fullDate: `Today, ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`,
      iconName: bill.icon,
      iconBg: 'bg-[#eff4ff]',
      iconColor: 'text-[#0b1f3a]',
      status: 'Completed',
      speed: 'Instant',
      paymentMethod: 'Nova Checking',
      reference: `BILL-${Math.floor(10000 + Math.random() * 90000)}-NV`,
      address: 'Utility Payment Clearing',
      categoryType: 'bills',
    };

    setTransactions((prev) => [newTx, ...prev]);
  };

  const handleAddCard = (card: CardInfo) => {
    setCards((prev) => [card, ...prev]);
    showToast(`New ${card.type} card added with ending •••• ${card.lastFour}`);
  };

  const handleOpenSplitBill = (tx: Transaction) => {
    setSplitTransaction(tx);
    setSplitBillModalOpen(true);
  };

  const handleConfirmSplit = (amountPerPerson: number, count: number) => {
    showToast(
      `Split requests of $${amountPerPerson.toFixed(2)} sent to ${count - 1} contacts.`
    );
  };

  const handleMarkAllNotificationsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
    showToast('All notifications marked as read.');
  };

  const unreadNotificationsCount = notifications.filter((n) => !n.read).length;

  return (
    <div className="min-h-screen bg-[#f7f9fe] text-[#0b1c30] flex flex-col items-center antialiased selection:bg-[#6df5e1] selection:text-[#00201c] relative font-['Inter',sans-serif]">
      {/* Dynamic Toast Banner */}
      {toastMessage && (
        <div className="fixed top-4 z-50 px-4 w-full max-w-sm pointer-events-none animate-in fade-in slide-in-from-top-4 duration-300">
          <div className="bg-[#0b1f3a]/95 text-white backdrop-blur-md px-4 py-3 rounded-2xl shadow-xl flex items-center gap-3 border border-white/10 pointer-events-auto">
            <span className="material-symbols-outlined text-[#6df5e1] text-[20px]">
              check_circle
            </span>
            <span className="text-[13px] font-medium leading-snug flex-1">
              {toastMessage}
            </span>
            <button
              onClick={() => setToastMessage(null)}
              className="text-white/60 hover:text-white"
            >
              <span className="material-symbols-outlined text-[16px]">close</span>
            </button>
          </div>
        </div>
      )}

      {/* Main Container */}
      <div className="w-full max-w-md min-h-screen flex flex-col bg-[#f7f9fe] relative shadow-2xl">
        {!isAuthenticated ? (
          <LoginScreen
            onLoginSuccess={() => {
              setIsAuthenticated(true);
              showToast('Welcome back, Alex!');
            }}
            onShowToast={showToast}
          />
        ) : (
          <>
            {/* Top Navigation Bar */}
            <TopBar
              currentScreen={currentScreen}
              onNavigate={handleNavigate}
              onBack={handleBack}
              unreadCount={unreadNotificationsCount}
              onOpenNotifications={() => setNotificationsOpen(true)}
            />

            {/* Main Content Area */}
            <main className="flex-1 w-full flex flex-col">
              {currentScreen === 'home' && (
                <HomeScreen
                  user={user}
                  balance={userBalance}
                  transactions={transactions}
                  onSelectTransaction={handleSelectTransaction}
                  onNavigateToPayments={() => handleNavigate('payments')}
                  onOpenSend={() => setSendModalOpen(true)}
                  onOpenRequest={() => showToast('Payment request link copied to clipboard ($50.00)')}
                  onOpenTopUp={() => setTopUpModalOpen(true)}
                  onOpenNotifications={() => setNotificationsOpen(true)}
                  onShowToast={showToast}
                />
              )}

              {currentScreen === 'cards' && (
                <CardsScreen
                  cards={cards}
                  transactions={transactions}
                  onSelectTransaction={handleSelectTransaction}
                  onShowToast={showToast}
                  onOpenAddCard={() => setAddCardModalOpen(true)}
                />
              )}

              {currentScreen === 'payments' && (
                <PaymentsScreen
                  bills={bills}
                  onPayBill={handlePayBill}
                  onShowToast={showToast}
                />
              )}

              {currentScreen === 'insights' && (
                <InsightsScreen onShowToast={showToast} />
              )}

              {currentScreen === 'profile' && (
                <ProfileScreen
                  user={user}
                  onLogout={() => {
                    setIsAuthenticated(false);
                    showToast('Logged out securely.');
                  }}
                  onShowToast={showToast}
                />
              )}

              {currentScreen === 'transaction-detail' && selectedTransaction && (
                <TransactionDetailScreen
                  transaction={selectedTransaction}
                  onBack={handleBack}
                  onShowToast={showToast}
                  onOpenSplitBill={handleOpenSplitBill}
                />
              )}
            </main>

            {/* Bottom Navigation */}
            {currentScreen !== 'transaction-detail' && (
              <BottomNav
                currentScreen={currentScreen}
                onNavigate={handleNavigate}
              />
            )}
          </>
        )}
      </div>

      {/* Modals and Sheets */}
      <SendMoneyModal
        isOpen={sendModalOpen}
        onClose={() => setSendModalOpen(false)}
        balance={userBalance}
        onSend={handleSendMoney}
      />

      <TopUpModal
        isOpen={topUpModalOpen}
        onClose={() => setTopUpModalOpen(false)}
        onTopUp={handleTopUp}
      />

      <SplitBillModal
        isOpen={splitBillModalOpen}
        onClose={() => setSplitBillModalOpen(false)}
        transaction={splitTransaction}
        onConfirmSplit={handleConfirmSplit}
      />

      <NotificationsSheet
        isOpen={notificationsOpen}
        onClose={() => setNotificationsOpen(false)}
        notifications={notifications}
        onMarkAllAsRead={handleMarkAllNotificationsRead}
      />

      <AddCardModal
        isOpen={addCardModalOpen}
        onClose={() => setAddCardModalOpen(false)}
        onAddCard={handleAddCard}
      />
    </div>
  );
}
export default App;
