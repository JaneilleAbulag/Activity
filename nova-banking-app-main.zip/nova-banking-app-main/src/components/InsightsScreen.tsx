import React, { useState } from 'react';
import {
  FOOD_RECEIPT_IMAGE,
  SHOPPING_RECEIPT_IMAGE,
  MONTHLY_INSIGHTS_DATA,
} from '../data/mockData';

interface InsightsScreenProps {
  onShowToast: (msg: string) => void;
}

export const InsightsScreen: React.FC<InsightsScreenProps> = ({ onShowToast }) => {
  const months = ['July 2026', 'August 2026', 'September 2026', 'October 2026'];
  const [monthIndex, setMonthIndex] = useState(2); // 'September 2026'
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [vacationFund, setVacationFund] = useState(MONTHLY_INSIGHTS_DATA.vacationGoal.current);
  const [selectedReceipt, setSelectedReceipt] = useState<{
    title: string;
    date: string;
    amount: string;
    image: string;
    tag: string;
  } | null>(null);

  const currentMonth = months[monthIndex];
  const vacationTarget = MONTHLY_INSIGHTS_DATA.vacationGoal.target;
  const vacationPct = Math.min(100, Math.round((vacationFund / vacationTarget) * 100));
  const vacationRemaining = Math.max(0, vacationTarget - vacationFund);

  const handleDepositToGoal = () => {
    if (vacationFund >= vacationTarget) {
      onShowToast('Vacation Fund goal already 100% achieved! Pack your bags!');
      return;
    }
    const newAmount = Math.min(vacationTarget, vacationFund + 150);
    setVacationFund(newAmount);
    onShowToast(`$150.00 deposited into Vacation Fund. Current: $${newAmount.toLocaleString()}`);
  };

  return (
    <div className="flex flex-col w-full px-4 space-y-4 pb-24 select-none max-w-md mx-auto">
      {/* Header & Month Selector */}
      <div className="flex items-center justify-between pt-1">
        <div className="flex flex-col">
          <span className="text-[28px] font-semibold text-[#0b1c30] tracking-tight leading-[34px]">
            Insights
          </span>
          <span className="text-[13px] text-[#44474d]">
            Monthly spending trends
          </span>
        </div>

        {/* Month Navigation Pill */}
        <div className="flex items-center bg-white rounded-full shadow-sm p-1 border border-[#0b1f3a]/5">
          <button
            onClick={() => {
              if (monthIndex > 0) setMonthIndex(monthIndex - 1);
            }}
            disabled={monthIndex === 0}
            aria-label="Previous month"
            className="w-10 h-10 flex items-center justify-center text-[#44474d] active:scale-95 transition-transform rounded-full hover:bg-[#eff4ff] disabled:opacity-30"
          >
            <span className="material-symbols-outlined text-[18px]">chevron_left</span>
          </button>

          <div className="flex items-center gap-1 px-2 h-10 text-[#0b1c30] text-[13px] font-semibold">
            <span>{currentMonth}</span>
          </div>

          <button
            onClick={() => {
              if (monthIndex < months.length - 1) setMonthIndex(monthIndex + 1);
            }}
            disabled={monthIndex === months.length - 1}
            aria-label="Next month"
            className="w-10 h-10 flex items-center justify-center text-[#44474d] active:scale-95 transition-transform rounded-full hover:bg-[#eff4ff] disabled:opacity-30"
          >
            <span className="material-symbols-outlined text-[18px]">chevron_right</span>
          </button>
        </div>
      </div>

      {/* Smart Delight Tip Banner */}
      <div className="bg-[#eff4ff] rounded-xl p-4 shadow-sm relative overflow-hidden flex items-start gap-3 border border-[#0b1f3a]/5">
        <div className="w-10 h-10 rounded-full bg-[#6df5e1] flex items-center justify-center flex-shrink-0 text-[#006f64]">
          <span
            className="material-symbols-outlined text-[20px]"
            style={{ fontVariationSettings: "'FILL' 1" }}
          >
            auto_awesome
          </span>
        </div>
        <div className="flex-1 min-w-0 pr-6">
          <div className="flex items-center gap-1.5">
            <span className="text-[13px] font-semibold text-[#006b5f]">Smart Insight</span>
            <span className="w-1.5 h-1.5 rounded-full bg-[#006b5f]" />
            <span className="text-[11px] font-semibold text-[#44474d]">Positive pacing</span>
          </div>
          <p className="text-[15px] text-[#0b1c30] mt-0.5 leading-snug">
            You spent <span className="font-semibold text-[#006b5f]">12% less</span> on dining out than last month. Keep up this momentum!
          </p>
        </div>
        <div className="absolute -right-4 -bottom-4 w-16 h-16 rounded-full bg-[#6df5e1]/40 blur-xl pointer-events-none" />
      </div>

      {/* Donut Chart & Category Breakdown Bento Card */}
      <div className="bg-white rounded-xl p-4 shadow-sm flex flex-col space-y-4 border border-[#0b1f3a]/5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[20px] text-[#000615]">donut_large</span>
            <h2 className="text-[17px] font-semibold text-[#0b1c30]">Spending Breakdown</h2>
          </div>
          <span className="text-[11px] font-semibold bg-[#e5eeff] px-2.5 py-1 rounded-full text-[#44474d]">
            5 Categories
          </span>
        </div>

        {/* Center SVG Donut Chart with Cutout Details */}
        <div className="relative w-full flex items-center justify-center py-2">
          <div className="relative w-48 h-48 flex items-center justify-center">
            {/* SVG Donut (Circumference ~ 439.82 for r=70) */}
            <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 160 160">
              <circle
                cx="80"
                cy="80"
                fill="transparent"
                r="70"
                stroke="#eff4ff"
                strokeWidth="18"
              />
              {MONTHLY_INSIGHTS_DATA.categories.map((cat) => {
                const isHovered = activeCategory === cat.name;
                return (
                  <circle
                    key={cat.name}
                    cx="80"
                    cy="80"
                    fill="transparent"
                    r="70"
                    stroke={cat.color}
                    strokeWidth={isHovered ? '22' : '18'}
                    strokeDasharray={cat.strokeDash}
                    strokeDashoffset={cat.offset}
                    className="transition-all duration-300 cursor-pointer hover:opacity-90"
                    onMouseEnter={() => setActiveCategory(cat.name)}
                    onMouseLeave={() => setActiveCategory(null)}
                    onClick={() => {
                      setActiveCategory(activeCategory === cat.name ? null : cat.name);
                      onShowToast(`${cat.name}: $${cat.amount.toFixed(2)} (${cat.pct}%)`);
                    }}
                  />
                );
              })}
            </svg>

            {/* Center Cutout Numeric Hero */}
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center pointer-events-none">
              <span className="text-[11px] font-semibold text-[#44474d] tracking-wider uppercase">
                {activeCategory || 'Total Spent'}
              </span>
              <span className="text-[24px] font-semibold text-[#000615] mt-0.5">
                {activeCategory
                  ? `$${MONTHLY_INSIGHTS_DATA.categories
                      .find((c) => c.name === activeCategory)
                      ?.amount.toFixed(0)}`
                  : `$${MONTHLY_INSIGHTS_DATA.totalSpent.toLocaleString()}`}
              </span>
              <span className="text-[11px] font-semibold text-[#006b5f] flex items-center">
                <span className="material-symbols-outlined text-[14px]">trending_down</span>
                4.1%
              </span>
            </div>
          </div>
        </div>

        {/* Category Stack */}
        <div className="flex flex-col space-y-2 pt-1">
          {MONTHLY_INSIGHTS_DATA.categories.map((cat) => {
            const isHighlight = activeCategory === cat.name;
            return (
              <div
                key={cat.name}
                onClick={() => {
                  setActiveCategory(activeCategory === cat.name ? null : cat.name);
                  onShowToast(`${cat.name}: $${cat.amount.toFixed(2)} (${cat.pct}%)`);
                }}
                className={`flex items-center justify-between p-2.5 rounded-lg transition-all cursor-pointer min-h-[44px] ${
                  isHighlight ? 'bg-[#dce9ff] shadow-xs' : 'bg-[#eff4ff] hover:bg-[#e5eeff]'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className="w-3 h-3 rounded-full flex-shrink-0"
                    style={{ backgroundColor: cat.color }}
                  />
                  <div className="flex flex-col min-w-0">
                    <span className="text-[13px] font-semibold text-[#0b1c30] truncate">
                      {cat.name}
                    </span>
                    <span className="text-[13px] text-[#44474d]">
                      {cat.pct}% of overall
                    </span>
                  </div>
                </div>
                <div className="text-right flex-shrink-0 pl-2">
                  <span className="text-[13px] font-semibold text-[#0b1c30] tabular-nums">
                    ${cat.amount.toFixed(2)}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Income vs Expenses Comparative Card */}
      <div className="bg-white rounded-xl p-4 shadow-sm flex flex-col space-y-4 border border-[#0b1f3a]/5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[20px] text-[#000615]">balance</span>
            <h2 className="text-[17px] font-semibold text-[#0b1c30]">Income vs Expenses</h2>
          </div>
          <span className="text-[11px] bg-[#6df5e1] text-[#006f64] px-2.5 py-1 rounded-full font-semibold">
            +${MONTHLY_INSIGHTS_DATA.savingsAmount.toLocaleString()}.00 saved
          </span>
        </div>

        {/* Comparative Progress Bars */}
        <div className="space-y-4">
          {/* Income bar */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <div className="flex items-center gap-1.5">
                <span className="w-5 h-5 rounded-full bg-[#6df5e1]/40 flex items-center justify-center text-[#006f64]">
                  <span className="material-symbols-outlined text-[13px]">arrow_upward</span>
                </span>
                <span className="text-[13px] font-semibold text-[#0b1c30]">Total Income</span>
              </div>
              <span className="text-[13px] text-[#0b1c30] tabular-nums font-semibold">
                ${MONTHLY_INSIGHTS_DATA.totalIncome.toFixed(2)}
              </span>
            </div>
            <div className="w-full h-3 bg-[#e5eeff] rounded-full overflow-hidden">
              <div className="h-full bg-[#006b5f] rounded-full w-full" />
            </div>
          </div>

          {/* Expenses bar */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <div className="flex items-center gap-1.5">
                <span className="w-5 h-5 rounded-full bg-[#d3e4fe] flex items-center justify-center text-[#0b1f3a]">
                  <span className="material-symbols-outlined text-[13px]">arrow_downward</span>
                </span>
                <span className="text-[13px] font-semibold text-[#0b1c30]">Total Expenses</span>
              </div>
              <span className="text-[13px] text-[#0b1c30] tabular-nums font-semibold">
                ${MONTHLY_INSIGHTS_DATA.totalExpenses.toFixed(2)}
              </span>
            </div>
            <div className="w-full h-3 bg-[#e5eeff] rounded-full overflow-hidden">
              <div
                className="h-full bg-[#0b1f3a] rounded-full"
                style={{
                  width: `${(MONTHLY_INSIGHTS_DATA.totalExpenses / MONTHLY_INSIGHTS_DATA.totalIncome) * 100}%`,
                }}
              />
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between pt-1 text-[#44474d] text-[13px]">
          <span>Savings rate</span>
          <span className="text-[13px] text-[#006b5f] font-semibold">
            {MONTHLY_INSIGHTS_DATA.savingsRatePct}% of income
          </span>
        </div>
      </div>

      {/* Vacation Fund Goal Progress Card */}
      <div className="bg-white rounded-xl p-4 shadow-sm flex flex-col space-y-2 relative overflow-hidden border border-[#0b1f3a]/5">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-[#6df5e1]/60 flex items-center justify-center text-[#006f64] flex-shrink-0">
              <span className="material-symbols-outlined text-[24px]">flight_takeoff</span>
            </div>
            <div className="flex flex-col min-w-0">
              <span className="text-[17px] font-semibold text-[#0b1c30] truncate">
                Vacation Fund
              </span>
              <span className="text-[13px] text-[#44474d]">Annual retreat goal</span>
            </div>
          </div>
          <span className="text-[13px] text-[#006b5f] bg-[#6df5e1]/50 px-2.5 py-1 rounded-full font-semibold">
            {vacationPct}% achieved
          </span>
        </div>

        {/* Progress Amount Stats */}
        <div className="flex items-baseline justify-between pt-2">
          <span className="text-[24px] font-semibold text-[#000615]">
            ${vacationFund.toLocaleString()}{' '}
            <span className="text-[15px] text-[#44474d] font-normal">
              / ${vacationTarget.toLocaleString()}
            </span>
          </span>
          <span className="text-[11px] font-semibold text-[#44474d]">
            ${vacationRemaining.toLocaleString()} to go
          </span>
        </div>

        {/* Progress Bar */}
        <div className="w-full h-3.5 bg-[#e5eeff] rounded-full overflow-hidden p-0.5">
          <div
            className="h-full bg-[#006b5f] rounded-full relative transition-all duration-500 ease-out"
            style={{ width: `${vacationPct}%` }}
          >
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/25 to-transparent" />
          </div>
        </div>

        {/* Goal timeline footer */}
        <div className="flex items-center justify-between pt-1">
          <div className="flex items-center gap-1.5 text-[#44474d] text-[13px]">
            <span className="material-symbols-outlined text-[16px] text-[#006b5f]">check_circle</span>
            <span>On track for Dec 2026</span>
          </div>
          <button
            onClick={handleDepositToGoal}
            className="text-[11px] font-semibold text-[#006b5f] hover:underline flex items-center gap-0.5 active:scale-95 transition-transform cursor-pointer"
          >
            Deposit +$150 <span className="material-symbols-outlined text-[14px]">arrow_forward</span>
          </button>
        </div>
      </div>

      {/* Interactive Monthly Trends Micro-Gallery */}
      <div className="flex items-center justify-between pt-1">
        <h3 className="text-[17px] font-semibold text-[#0b1c30]">Recent Receipts</h3>
        <button
          onClick={() => onShowToast('Receipt vault: 18 scanned receipts archived.')}
          className="text-[13px] font-semibold text-[#006b5f] hover:underline"
        >
          View All
        </button>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {/* Receipt visual card 1 */}
        <div
          onClick={() =>
            setSelectedReceipt({
              title: "L'Artisan Bistro",
              date: 'Sep 18, 2026',
              amount: '$142.50',
              image: FOOD_RECEIPT_IMAGE,
              tag: 'Food & Dining',
            })
          }
          className="bg-white rounded-xl p-3 shadow-sm flex flex-col space-y-2 border border-[#0b1f3a]/5 hover:shadow-md transition-shadow cursor-pointer active:scale-95"
        >
          <div className="w-full h-24 rounded-lg overflow-hidden relative">
            <img
              alt="Artisanal bistro dining"
              className="w-full h-full object-cover"
              src={FOOD_RECEIPT_IMAGE}
            />
            <span className="absolute bottom-1.5 right-1.5 bg-[#0b1f3a]/85 text-white text-[11px] font-semibold px-1.5 py-0.5 rounded backdrop-blur-sm">
              Food
            </span>
          </div>
          <div className="flex flex-col min-w-0">
            <span className="text-[13px] font-semibold text-[#0b1c30] truncate">
              L'Artisan Bistro
            </span>
            <span className="text-[13px] text-[#44474d]">Sep 18 • $142.50</span>
          </div>
        </div>

        {/* Receipt visual card 2 */}
        <div
          onClick={() =>
            setSelectedReceipt({
              title: 'Studio Nordique',
              date: 'Sep 14, 2026',
              amount: '$215.00',
              image: SHOPPING_RECEIPT_IMAGE,
              tag: 'Interior Shopping',
            })
          }
          className="bg-white rounded-xl p-3 shadow-sm flex flex-col space-y-2 border border-[#0b1f3a]/5 hover:shadow-md transition-shadow cursor-pointer active:scale-95"
        >
          <div className="w-full h-24 rounded-lg overflow-hidden relative">
            <img
              alt="Scandinavian minimalist store"
              className="w-full h-full object-cover"
              src={SHOPPING_RECEIPT_IMAGE}
            />
            <span className="absolute bottom-1.5 right-1.5 bg-[#1f8dd1]/85 text-white text-[11px] font-semibold px-1.5 py-0.5 rounded backdrop-blur-sm">
              Shopping
            </span>
          </div>
          <div className="flex flex-col min-w-0">
            <span className="text-[13px] font-semibold text-[#0b1c30] truncate">
              Studio Nordique
            </span>
            <span className="text-[13px] text-[#44474d]">Sep 14 • $215.00</span>
          </div>
        </div>
      </div>

      {/* Receipt Lightbox Modal */}
      {selectedReceipt && (
        <div className="fixed inset-0 z-50 bg-[#0b1f3a]/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-5 w-full max-w-sm shadow-xl flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-[17px] font-semibold text-[#0b1c30]">
                  {selectedReceipt.title}
                </h3>
                <span className="text-[13px] text-[#44474d]">
                  {selectedReceipt.date} • {selectedReceipt.amount}
                </span>
              </div>
              <button
                onClick={() => setSelectedReceipt(null)}
                className="w-8 h-8 rounded-full flex items-center justify-center text-[#44474d] hover:bg-[#eff4ff]"
              >
                <span className="material-symbols-outlined text-[20px]">close</span>
              </button>
            </div>

            <div className="w-full h-48 rounded-xl overflow-hidden shadow-inner">
              <img
                src={selectedReceipt.image}
                alt={selectedReceipt.title}
                className="w-full h-full object-cover"
              />
            </div>

            <div className="flex items-center justify-between text-[13px] text-[#44474d] bg-[#eff4ff] p-3 rounded-xl">
              <span>Category: <strong>{selectedReceipt.tag}</strong></span>
              <span className="text-[#006b5f] font-semibold">Tax Deductible</span>
            </div>

            <button
              onClick={() => {
                setSelectedReceipt(null);
                onShowToast(`Exported ${selectedReceipt.title} receipt to Files.`);
              }}
              className="w-full h-11 bg-[#0b1f3a] text-white rounded-xl text-[13px] font-semibold flex items-center justify-center gap-2"
            >
              <span className="material-symbols-outlined text-[18px]">download</span>
              <span>Export Verified Receipt</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
