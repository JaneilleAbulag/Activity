import React, { useState } from 'react';

interface SendMoneyModalProps {
  isOpen: boolean;
  onClose: () => void;
  balance: number;
  onSend: (recipient: string, amount: number, note: string) => void;
}

export const SendMoneyModal: React.FC<SendMoneyModalProps> = ({
  isOpen,
  onClose,
  balance,
  onSend,
}) => {
  const [recipient, setRecipient] = useState('Sarah Jenkins');
  const [amount, setAmount] = useState('45.00');
  const [note, setNote] = useState('Dinner split 🍕');
  const [isSending, setIsSending] = useState(false);

  if (!isOpen) return null;

  const quickAmounts = [25, 50, 100, 200];
  const contacts = [
    { name: 'Sarah Jenkins', handle: '@sarahj', avatar: 'SJ' },
    { name: 'Michael Chen', handle: '@mchen', avatar: 'MC' },
    { name: 'Emma Watson', handle: '@emwats', avatar: 'EW' },
    { name: 'David Miller', handle: '@davidm', avatar: 'DM' },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) return;
    if (numAmount > balance) {
      alert('Insufficient funds in checking account.');
      return;
    }

    setIsSending(true);
    setTimeout(() => {
      setIsSending(false);
      onSend(recipient, numAmount, note);
      onClose();
    }, 700);
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#0b1f3a]/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-white rounded-t-3xl sm:rounded-2xl w-full max-w-md p-6 shadow-2xl flex flex-col gap-4 animate-in slide-in-from-bottom duration-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-full bg-[#eff4ff] flex items-center justify-center text-[#0b1f3a]">
              <span className="material-symbols-outlined text-[20px]">send</span>
            </div>
            <h3 className="text-[17px] font-semibold text-[#0b1c30]">Send Money</h3>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-[#44474d] hover:bg-[#eff4ff]"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        {/* Recent Contacts */}
        <div className="flex flex-col gap-2">
          <span className="text-[11px] font-semibold text-[#44474d] uppercase tracking-wider">
            Quick Contacts
          </span>
          <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
            {contacts.map((c) => (
              <button
                key={c.name}
                type="button"
                onClick={() => setRecipient(c.name)}
                className={`flex flex-col items-center p-2 rounded-xl border min-w-[76px] transition-all ${
                  recipient === c.name
                    ? 'border-[#006b5f] bg-[#6df5e1]/10 text-[#006b5f]'
                    : 'border-[#0b1f3a]/5 hover:bg-[#eff4ff] text-[#0b1c30]'
                }`}
              >
                <div className="w-10 h-10 rounded-full bg-[#eff4ff] text-[#0b1f3a] font-bold text-xs flex items-center justify-center mb-1">
                  {c.avatar}
                </div>
                <span className="text-[11px] font-semibold truncate w-full text-center">
                  {c.name.split(' ')[0]}
                </span>
              </button>
            ))}
          </div>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div className="flex flex-col gap-1">
            <label className="text-[11px] font-semibold text-[#44474d]">To</label>
            <input
              type="text"
              value={recipient}
              onChange={(e) => setRecipient(e.target.value)}
              className="h-12 px-3 rounded-xl bg-[#eff4ff] text-[15px] font-medium outline-none focus:ring-2 focus:ring-[#006b5f]/30"
              placeholder="Name, @cashtag, or email"
              required
            />
          </div>

          <div className="flex flex-col gap-1">
            <div className="flex justify-between items-center">
              <label className="text-[11px] font-semibold text-[#44474d]">Amount ($)</label>
              <span className="text-[11px] text-[#44474d]">
                Available: ${balance.toFixed(2)}
              </span>
            </div>
            <div className="relative flex items-center">
              <span className="absolute left-4 text-2xl font-bold text-[#0b1c30]">$</span>
              <input
                type="number"
                step="0.01"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full h-14 pl-9 pr-4 rounded-xl bg-[#eff4ff] text-3xl font-bold text-[#0b1c30] outline-none focus:ring-2 focus:ring-[#006b5f]/30 font-['Inter']"
                placeholder="0.00"
                required
              />
            </div>

            {/* Quick Pills */}
            <div className="flex gap-2 mt-2">
              {quickAmounts.map((q) => (
                <button
                  key={q}
                  type="button"
                  onClick={() => setAmount(q.toFixed(2))}
                  className="flex-1 py-1.5 rounded-lg bg-[#eff4ff] hover:bg-[#dce9ff] text-[13px] font-semibold text-[#0b1c30]"
                >
                  ${q}
                </button>
              ))}
            </div>
          </div>

          <div className="flex flex-col gap-1">
            <label className="text-[11px] font-semibold text-[#44474d]">Note</label>
            <input
              type="text"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              className="h-11 px-3 rounded-xl bg-[#eff4ff] text-[13px] outline-none focus:ring-2 focus:ring-[#006b5f]/30"
              placeholder="What's this for?"
            />
          </div>

          <button
            type="submit"
            disabled={isSending}
            className="w-full h-13 bg-[#0b1f3a] text-white rounded-xl text-[15px] font-semibold shadow-sm flex items-center justify-center gap-2 mt-2 disabled:opacity-50 active:scale-[0.99] transition-all"
          >
            {isSending ? (
              <span className="flex items-center gap-2">
                <span className="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Sending money...
              </span>
            ) : (
              <>
                <span>Send Instantly</span>
                <span className="material-symbols-outlined text-[18px]">send</span>
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};
