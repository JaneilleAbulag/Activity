import React from 'react';
import { NOVA_LOGO_URL, USER_AVATAR_URL } from '../data/mockData';
import { ScreenType } from '../types';

interface TopBarProps {
  currentScreen: ScreenType;
  onNavigate: (screen: ScreenType) => void;
  onBack?: () => void;
  unreadCount?: number;
  onOpenNotifications: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  currentScreen,
  onNavigate,
  onBack,
  unreadCount = 2,
  onOpenNotifications,
}) => {
  // If we are on login screen, TopBar is minimalist with just status bar
  if (currentScreen === 'login') {
    return (
      <header className="sticky top-0 w-full z-40 bg-[#f8f9ff]/80 backdrop-blur-xl pt-1">
        <div className="w-full h-11 px-6 flex items-center justify-between text-[#0b1c30] select-none">
          <span className="text-[13px] font-semibold tracking-tight">9:41</span>
          <div className="flex items-center gap-1.5">
            <span className="material-symbols-outlined text-[16px]">signal_cellular_4_bar</span>
            <span className="material-symbols-outlined text-[16px]">wifi</span>
            <span className="material-symbols-outlined text-[20px]">battery_full</span>
          </div>
        </div>
      </header>
    );
  }

  const isDetailScreen = currentScreen === 'transaction-detail';

  return (
    <header className="sticky top-0 w-full z-40 bg-[#f8f9ff]/90 backdrop-blur-xl shadow-[0_1px_8px_rgba(0,0,0,0.04)] pt-1">
      {/* iOS Status Bar */}
      <div className="w-full h-11 px-6 flex items-center justify-between text-[#0b1c30] select-none">
        <span className="text-[13px] font-semibold tracking-tight">9:41</span>
        <div className="flex items-center gap-1.5">
          <span className="material-symbols-outlined text-[16px]">signal_cellular_4_bar</span>
          <span className="material-symbols-outlined text-[16px]">wifi</span>
          <span className="material-symbols-outlined text-[20px]">battery_full</span>
        </div>
      </div>

      {/* Main App Bar */}
      <div className="h-16 px-4 flex items-center justify-between">
        {isDetailScreen ? (
          <div className="flex items-center gap-1">
            <button
              onClick={onBack}
              aria-label="Go back"
              className="w-11 h-11 -ml-2 flex items-center justify-center text-[#0b1c30] hover:text-[#006b5f] transition-colors rounded-full active:scale-95"
            >
              <span className="material-symbols-outlined text-[22px]">arrow_back_ios_new</span>
            </button>
            <img
              alt="Nova Bank Logo"
              className="h-7 w-auto object-contain"
              src={NOVA_LOGO_URL}
            />
            <h1 className="text-[17px] font-semibold tracking-tight text-[#0b1c30] ml-1 truncate max-w-[200px]">
              Transaction Detail
            </h1>
          </div>
        ) : (
          <div
            className="flex items-center gap-2 cursor-pointer"
            onClick={() => onNavigate('home')}
          >
            <img
              alt="Nova Bank Logo"
              className="h-8 w-auto object-contain"
              src={NOVA_LOGO_URL}
            />
            <span className="text-[17px] font-semibold tracking-tight text-[#0b1c30]">
              Nova Bank
            </span>
          </div>
        )}

        <div className="flex items-center gap-1">
          {!isDetailScreen && (
            <button
              onClick={onOpenNotifications}
              aria-label="Notifications"
              className="relative w-11 h-11 flex items-center justify-center text-[#44474d] hover:text-[#0b1c30] transition-colors rounded-full active:scale-95"
            >
              <span className="material-symbols-outlined text-[22px]">notifications</span>
              {unreadCount > 0 && (
                <span className="absolute top-2 right-2 w-2.5 h-2.5 bg-[#ba1a1a] rounded-full ring-2 ring-[#f8f9ff]" />
              )}
            </button>
          )}

          <button
            onClick={() => onNavigate('profile')}
            aria-label="Profile"
            className="w-8 h-8 rounded-full overflow-hidden ml-1 ring-2 ring-transparent hover:ring-[#006b5f]/30 transition-all active:scale-95"
          >
            <img
              alt="Profile"
              className="w-full h-full object-cover"
              src={USER_AVATAR_URL}
            />
          </button>
        </div>
      </div>
    </header>
  );
};
