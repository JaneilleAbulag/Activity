import React from 'react';
import { NotificationItem } from '../types';

interface NotificationsSheetProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: NotificationItem[];
  onMarkAllAsRead: () => void;
}

export const NotificationsSheet: React.FC<NotificationsSheetProps> = ({
  isOpen,
  onClose,
  notifications,
  onMarkAllAsRead,
}) => {
  if (!isOpen) return null;

  const getIcon = (type: NotificationItem['type']) => {
    switch (type) {
      case 'payment':
        return 'account_balance_wallet';
      case 'security':
        return 'warning';
      case 'reward':
        return 'stars';
      case 'system':
      default:
        return 'notifications';
    }
  };

  const getIconColor = (type: NotificationItem['type']) => {
    switch (type) {
      case 'payment':
        return 'bg-[#6df5e1]/30 text-[#006b5f]';
      case 'security':
        return 'bg-[#ffdad6] text-[#ba1a1a]';
      case 'reward':
        return 'bg-[#dce9ff] text-[#1f8dd1]';
      case 'system':
      default:
        return 'bg-[#eff4ff] text-[#0b1f3a]';
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#0b1f3a]/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-white rounded-t-3xl sm:rounded-2xl w-full max-w-md p-6 shadow-2xl flex flex-col gap-4 max-h-[85vh] overflow-y-auto animate-in slide-in-from-bottom duration-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-full bg-[#eff4ff] flex items-center justify-center text-[#0b1f3a]">
              <span className="material-symbols-outlined text-[20px]">notifications</span>
            </div>
            <h3 className="text-[17px] font-semibold text-[#0b1c30]">Notifications</h3>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-[#44474d] hover:bg-[#eff4ff]"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        <div className="flex justify-between items-center text-[13px]">
          <span className="text-[#44474d]">Recent alerts &amp; account updates</span>
          <button
            onClick={onMarkAllAsRead}
            className="text-[#006b5f] font-semibold hover:underline"
          >
            Mark all read
          </button>
        </div>

        <div className="flex flex-col divide-y divide-[#e5eeff]">
          {notifications.map((n) => (
            <div
              key={n.id}
              className={`py-3.5 flex gap-3 items-start transition-colors ${
                !n.read ? 'bg-[#eff4ff]/40 -mx-6 px-6' : ''
              }`}
            >
              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${getIconColor(
                  n.type
                )}`}
              >
                <span className="material-symbols-outlined text-[18px]">
                  {getIcon(n.type)}
                </span>
              </div>
              <div className="flex flex-col min-w-0 flex-1">
                <div className="flex items-center justify-between">
                  <span className="text-[13px] font-semibold text-[#0b1c30] truncate">
                    {n.title}
                  </span>
                  <span className="text-[11px] text-[#75777e]">{n.time}</span>
                </div>
                <p className="text-[13px] text-[#44474d] mt-0.5 leading-snug">
                  {n.message}
                </p>
              </div>
              {!n.read && (
                <span className="w-2 h-2 rounded-full bg-[#006b5f] mt-1.5 flex-shrink-0" />
              )}
            </div>
          ))}
        </div>

        <button
          onClick={onClose}
          className="w-full h-11 bg-[#0b1f3a] text-white rounded-xl text-[13px] font-semibold mt-2"
        >
          Dismiss
        </button>
      </div>
    </div>
  );
};
