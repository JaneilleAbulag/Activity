import React, { useState } from 'react';
import { NOVA_LOGO_URL } from '../data/mockData';

interface LoginScreenProps {
  onLoginSuccess: () => void;
  onShowToast: (msg: string) => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLoginSuccess, onShowToast }) => {
  const [email, setEmail] = useState('alex.morgan@example.com');
  const [password, setPassword] = useState('ValidPasscode2025');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isFaceScanning, setIsFaceScanning] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      onShowToast('Welcome back, Alex! Access granted.');
      onLoginSuccess();
    }, 800);
  };

  const handleFaceId = () => {
    setIsFaceScanning(true);
    onShowToast('Authenticating with Face ID biometric sensor...');
    setTimeout(() => {
      setIsFaceScanning(false);
      onShowToast('Face ID verified! Welcome back, Alex.');
      onLoginSuccess();
    }, 1200);
  };

  return (
    <div className="flex flex-col w-full px-4 pb-12 select-none max-w-md mx-auto">
      {/* Brand & Mascot Delight Area */}
      <div className="flex flex-col items-center pt-4 pb-6 text-center relative">
        {/* Soft Ambient Glow */}
        <div className="absolute top-2 w-32 h-32 bg-[#6df5e1]/20 rounded-full blur-2xl pointer-events-none -z-10" />

        {/* Logo Container with pulse */}
        <div className="relative group cursor-pointer">
          <div className="w-16 h-16 rounded-xl bg-white p-2 shadow-md flex items-center justify-center transition-transform active:scale-95 duration-200 border border-[#0b1f3a]/5">
            <img
              alt="Nova Bank Logo"
              className="w-full h-full object-contain rounded-lg pointer-events-none"
              src={NOVA_LOGO_URL}
            />
          </div>
          <span className="absolute -top-1 -right-1 flex h-3.5 w-3.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#006b5f] opacity-75" />
            <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-[#006b5f]" />
          </span>
        </div>

        <h1 className="mt-4 text-[22px] font-semibold leading-[28px] text-[#0b1f3a] tracking-tight">
          Nova Bank
        </h1>
        <p className="mt-1 text-[13px] text-[#44474d]">
          Banking, made simple.
        </p>
      </div>

      {/* Interactive Login Form Card */}
      <div className="bg-white rounded-xl p-4 shadow-sm flex flex-col gap-4 border border-[#0b1f3a]/5">
        {/* Dynamic Security Status Pill */}
        <div className="flex items-center justify-between px-3 py-1.5 rounded-full bg-[#eff4ff] text-[#44474d]">
          <div className="flex items-center gap-1.5">
            <span className="material-symbols-outlined text-[16px] text-[#006b5f]">verified_user</span>
            <span className="text-[11px] tracking-wide uppercase font-semibold text-[#006b5f]">
              Secure Core v4.2
            </span>
          </div>
          <span className="inline-flex items-center gap-1 text-[11px] text-[#006b5f] font-medium">
            <span className="w-1.5 h-1.5 rounded-full bg-[#006b5f]" />
            Encrypted
          </span>
        </div>

        <form onSubmit={handleLogin} className="flex flex-col gap-4">
          {/* Email Field */}
          <div className="flex flex-col gap-1.5">
            <label className="text-[11px] font-semibold text-[#44474d] px-1" htmlFor="emailInput">
              Email address
            </label>
            <div className="relative flex items-center bg-[#eff4ff] focus-within:bg-white focus-within:ring-2 focus-within:ring-[#006b5f]/30 rounded-xl transition-all duration-200">
              <div className="w-12 h-12 flex items-center justify-center text-[#44474d]">
                <span className="material-symbols-outlined text-[20px]">mail</span>
              </div>
              <input
                id="emailInput"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="w-full h-12 pr-4 bg-transparent outline-none text-[15px] text-[#0b1c30] placeholder:text-[#c4c6ce]"
                placeholder="alex.morgan@example.com"
              />
            </div>
          </div>

          {/* Password Field */}
          <div className="flex flex-col gap-1.5">
            <label className="text-[11px] font-semibold text-[#44474d] px-1" htmlFor="passwordInput">
              Password
            </label>
            <div className="relative flex items-center bg-[#eff4ff] focus-within:bg-white focus-within:ring-2 focus-within:ring-[#006b5f]/30 rounded-xl transition-all duration-200">
              <div className="w-12 h-12 flex items-center justify-center text-[#44474d]">
                <span className="material-symbols-outlined text-[20px]">lock</span>
              </div>
              <input
                id="passwordInput"
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="w-full h-12 bg-transparent outline-none text-[15px] text-[#0b1c30] tracking-wider placeholder:tracking-normal placeholder:text-[#c4c6ce]"
                placeholder="••••••••••••"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="w-11 h-11 flex items-center justify-center text-[#44474d] hover:text-[#0b1c30] active:scale-90 transition-transform mr-1"
                aria-label="Toggle password visibility"
              >
                <span className="material-symbols-outlined text-[20px]">
                  {showPassword ? 'visibility_off' : 'visibility'}
                </span>
              </button>
            </div>

            <div className="flex justify-end pt-0.5">
              <button
                type="button"
                onClick={() => onShowToast('Password reset link sent to your registered email.')}
                className="text-[13px] font-semibold text-[#006b5f] hover:underline transition-colors min-h-[32px] flex items-center"
              >
                Forgot password?
              </button>
            </div>
          </div>

          {/* Log In Button */}
          <button
            type="submit"
            disabled={isLoading}
            className="w-full h-[52px] mt-1 bg-[#0b1f3a] hover:bg-[#152e52] text-white rounded-xl text-[15px] font-semibold shadow-sm flex items-center justify-center gap-2 transition-all duration-150 active:scale-[0.99] cursor-pointer disabled:opacity-75"
          >
            {isLoading ? (
              <span className="flex items-center gap-2">
                <span className="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Verifying credentials...
              </span>
            ) : (
              <>
                <span>Log In</span>
                <span className="material-symbols-outlined text-[18px]">arrow_forward</span>
              </>
            )}
          </button>

          {/* Divider */}
          <div className="relative flex items-center justify-center my-0.5">
            <div className="w-full h-[1px] bg-[#e5eeff]" />
            <span className="absolute px-3 bg-white text-[11px] text-[#75777e] font-semibold">
              or authenticate with
            </span>
          </div>

          {/* Face ID Button */}
          <button
            type="button"
            onClick={handleFaceId}
            disabled={isFaceScanning}
            className="w-full h-[52px] bg-[#eff4ff] hover:bg-[#e5eeff] text-[#0b1f3a] rounded-xl text-[15px] font-semibold flex items-center justify-center gap-3 transition-colors duration-150 active:scale-[0.99] cursor-pointer"
          >
            {isFaceScanning ? (
              <span className="flex items-center gap-2 text-[#006b5f]">
                <span className="inline-block w-4 h-4 border-2 border-[#006b5f]/30 border-t-[#006b5f] rounded-full animate-spin" />
                Scanning Biometrics...
              </span>
            ) : (
              <>
                <svg
                  className="w-5 h-5 text-[#006b5f]"
                  fill="none"
                  stroke="currentColor"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  viewBox="0 0 24 24"
                >
                  <path d="M7 3H5a2 2 0 0 0-2 2v2" />
                  <path d="M17 3h2a2 2 0 0 1 2 2v2" />
                  <path d="M21 17v2a2 2 0 0 1-2 2h-2" />
                  <path d="M3 17v2a2 2 0 0 0 2 2h2" />
                  <circle cx="9" cy="9" fill="currentColor" r="1" />
                  <circle cx="15" cy="9" fill="currentColor" r="1" />
                  <path d="M10 13c.5.5 1.5 1 2 1s1.5-.5 2-1" />
                  <path d="M12 11v2" />
                </svg>
                <span>Log in with Face ID</span>
              </>
            )}
          </button>
        </form>
      </div>

      {/* Security Reassurance Footnote */}
      <div className="flex flex-col items-center gap-2 pt-6 text-center">
        <div className="inline-flex items-center gap-1.5 text-[#44474d] text-[11px] font-semibold">
          <span className="material-symbols-outlined text-[16px] text-[#006b5f]">lock</span>
          <span>Protected with 256-bit AES encryption</span>
        </div>

        <div className="flex items-center justify-center gap-1.5 text-[13px] min-h-[44px]">
          <span className="text-[#44474d]">New here?</span>
          <button
            type="button"
            onClick={() => onShowToast('Nova Instant Account Opening is ready for enrollment.')}
            className="text-[#006b5f] font-semibold hover:underline"
          >
            Create an account
          </button>
        </div>
      </div>
    </div>
  );
};
