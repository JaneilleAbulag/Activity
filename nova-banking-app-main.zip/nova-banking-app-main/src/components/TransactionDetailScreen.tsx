import React, { useState } from 'react';
import { Transaction } from '../types';

interface TransactionDetailProps {
  transaction: Transaction;
  onBack: () => void;
  onShowToast: (msg: string) => void;
  onOpenSplitBill: (tx: Transaction) => void;
}

export const TransactionDetailScreen: React.FC<TransactionDetailProps> = ({
  transaction,
  onBack,
  onShowToast,
  onOpenSplitBill,
}) => {
  const [isRecognized, setIsRecognized] = useState<boolean | null>(transaction.recognized ?? true);
  const [isCopied, setIsCopied] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);

  const handleCopyRef = () => {
    navigator.clipboard?.writeText(transaction.reference).catch(() => {});
    setIsCopied(true);
    onShowToast(`Reference ID ${transaction.reference} copied to clipboard`);
    setTimeout(() => setIsCopied(false), 2000);
  };

  const handleDownloadReceipt = () => {
    setIsDownloading(true);
    onShowToast(`Generating official statement & receipt for ${transaction.merchant}...`);
    setTimeout(() => {
      setIsDownloading(false);
      onShowToast(`Receipt PDF for ${transaction.merchant} saved to device.`);
    }, 1200);
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator
        .share({
          title: `${transaction.merchant} Receipt - Nova Bank`,
          text: `Transaction of $${transaction.amount.toFixed(2)} at ${transaction.merchant} (${transaction.reference})`,
          url: window.location.href,
        })
        .catch(() => {});
    } else {
      navigator.clipboard?.writeText(
        `Nova Bank Receipt: $${transaction.amount.toFixed(2)} at ${transaction.merchant} on ${transaction.fullDate}`
      ).catch(() => {});
      onShowToast('Receipt details copied to clipboard for sharing');
    }
  };

  return (
    <div className="flex flex-col w-full px-4 pb-20 gap-4 max-w-md mx-auto select-none">
      {/* Top Action Utility Row */}
      <div className="w-full flex items-center justify-between pt-1">
        <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#e5eeff]">
          <span className="material-symbols-outlined text-[#006b5f] text-[16px]">
            verified
          </span>
          <span className="text-[11px] font-semibold text-[#44474d] tracking-wide uppercase">
            Settled Transaction
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onOpenSplitBill(transaction)}
            aria-label="Split expense"
            className="w-11 h-11 flex items-center justify-center rounded-full bg-white text-[#0b1c30] shadow-sm active:scale-95 transition-transform border border-[#0b1f3a]/5 hover:bg-[#eff4ff]"
          >
            <span className="material-symbols-outlined text-[20px]">call_split</span>
          </button>
          <button
            onClick={handleShare}
            aria-label="Share transaction"
            className="w-11 h-11 flex items-center justify-center rounded-full bg-white text-[#0b1c30] shadow-sm active:scale-95 transition-transform border border-[#0b1f3a]/5 hover:bg-[#eff4ff]"
          >
            <span className="material-symbols-outlined text-[20px]">ios_share</span>
          </button>
        </div>
      </div>

      {/* Hero Transaction Summary */}
      <section className="flex flex-col items-center text-center pt-2 pb-2">
        {/* Merchant Avatar with Glow */}
        <div className="relative flex items-center justify-center mb-3">
          <div className="absolute w-24 h-24 rounded-full bg-[#6df5e1]/40 blur-xl" />
          <div className="relative w-[72px] h-[72px] rounded-full bg-[#006b5f] flex items-center justify-center text-white shadow-md">
            <span
              className="material-symbols-outlined text-[36px]"
              style={{ fontVariationSettings: "'FILL' 1" }}
            >
              {transaction.iconName}
            </span>
          </div>
          <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-white shadow-sm flex items-center justify-center">
            <span
              className="material-symbols-outlined text-[#006b5f] text-[16px]"
              style={{ fontVariationSettings: "'FILL' 1" }}
            >
              check_circle
            </span>
          </div>
        </div>

        {/* Merchant Title & Subtitle */}
        <h2 className="text-[22px] font-semibold text-[#000615] tracking-tight">
          {transaction.merchant}
        </h2>
        <p className="text-[13px] text-[#44474d] mt-0.5">
          {transaction.subCategory || transaction.category} • {transaction.branch || 'San Francisco'}
        </p>

        {/* Large Amount */}
        <div className="mt-2 flex items-baseline justify-center">
          <span className="text-[40px] font-bold text-[#000615] tracking-tight">
            {transaction.type === 'credit' ? '+' : '-'}${transaction.amount.toFixed(2)}
          </span>
        </div>

        {/* Status Pill & Chip */}
        <div className="mt-2.5 flex items-center gap-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#71f8e4] text-[#00201c] shadow-sm">
            <span
              className="material-symbols-outlined text-[15px]"
              style={{ fontVariationSettings: "'FILL' 1" }}
            >
              check
            </span>
            <span className="text-[13px] font-semibold">{transaction.status}</span>
          </div>
          <div className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-[#dce9ff] text-[#44474d]">
            <span className="material-symbols-outlined text-[14px]">bolt</span>
            <span className="text-[11px] font-semibold">{transaction.speed}</span>
          </div>
        </div>
      </section>

      {/* Rewards Banner */}
      {transaction.rewardsStars && (
        <div className="w-full bg-white rounded-xl p-3 shadow-sm flex items-center justify-between border border-[#0b1f3a]/5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#dce9ff] flex items-center justify-center text-[#1f8dd1]">
              <span className="material-symbols-outlined text-[22px]">auto_awesome</span>
            </div>
            <div className="flex flex-col text-left">
              <span className="text-[13px] font-semibold text-[#0b1c30]">
                +{transaction.rewardsStars} Nova Stars Earned
              </span>
              <span className="text-[13px] text-[#44474d]">
                {transaction.rewardNote || 'Dining points applied'}
              </span>
            </div>
          </div>
          <span className="material-symbols-outlined text-[#44474d] text-[20px]">
            chevron_right
          </span>
        </div>
      )}

      {/* Transaction Details Structured Card */}
      <section className="bg-white rounded-xl shadow-sm overflow-hidden border border-[#0b1f3a]/5">
        <div className="px-4 py-3 bg-[#eff4ff] flex items-center justify-between">
          <span className="text-[13px] font-semibold text-[#0b1c30] uppercase tracking-wider">
            Payment Metadata
          </span>
          <span className="text-[11px] font-semibold text-[#006b5f]">Verified Ledger</span>
        </div>

        {/* Row 1: Date & Time */}
        <div className="px-4 py-3.5 flex items-center justify-between bg-white border-b border-[#e5eeff]">
          <div className="flex items-center gap-3">
            <span className="material-symbols-outlined text-[#44474d] text-[20px]">
              schedule
            </span>
            <span className="text-[15px] text-[#44474d]">Date &amp; Time</span>
          </div>
          <span className="text-[13px] font-semibold text-[#0b1c30] text-right">
            {transaction.fullDate}
          </span>
        </div>

        {/* Row 2: Category */}
        <div className="px-4 py-3.5 flex items-center justify-between bg-white border-b border-[#e5eeff]">
          <div className="flex items-center gap-3">
            <span className="material-symbols-outlined text-[#44474d] text-[20px]">
              restaurant
            </span>
            <span className="text-[15px] text-[#44474d]">Category</span>
          </div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#dce9ff] text-[#0b1c30]">
            <span className="text-[13px] font-semibold">{transaction.category}</span>
          </div>
        </div>

        {/* Row 3: Payment Method */}
        <div className="px-4 py-3.5 flex items-center justify-between bg-white border-b border-[#e5eeff]">
          <div className="flex items-center gap-3">
            <span className="material-symbols-outlined text-[#44474d] text-[20px]">
              credit_card
            </span>
            <span className="text-[15px] text-[#44474d]">Payment Method</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-6 h-4 rounded bg-[#000615] flex items-center justify-end px-1 shadow-xs">
              <div className="w-2 h-2 rounded-full bg-[#006b5f]" />
            </div>
            <span className="text-[13px] font-semibold text-[#0b1c30]">
              {transaction.paymentMethod}
            </span>
          </div>
        </div>

        {/* Row 4: Reference Number */}
        <div className="px-4 py-3.5 flex items-center justify-between bg-white border-b border-[#e5eeff]">
          <div className="flex items-center gap-3">
            <span className="material-symbols-outlined text-[#44474d] text-[20px]">
              tag
            </span>
            <span className="text-[15px] text-[#44474d]">Reference</span>
          </div>
          <button
            onClick={handleCopyRef}
            aria-label="Copy Reference Number"
            className="flex items-center gap-1.5 py-1 px-2.5 rounded-lg bg-[#e5eeff] active:scale-95 transition-transform"
          >
            <span className="text-[13px] font-semibold text-[#0b1c30] font-mono tracking-tight">
              {transaction.reference}
            </span>
            <span className="material-symbols-outlined text-[#006b5f] text-[16px]">
              {isCopied ? 'check' : 'content_copy'}
            </span>
          </button>
        </div>

        {/* Row 5: Merchant Address */}
        <div className="px-4 py-3.5 flex items-center justify-between bg-white">
          <div className="flex items-center gap-3">
            <span className="material-symbols-outlined text-[#44474d] text-[20px]">
              pin_drop
            </span>
            <span className="text-[15px] text-[#44474d]">Merchant Address</span>
          </div>
          <span className="text-[13px] font-semibold text-[#0b1c30] text-right truncate max-w-[190px]">
            {transaction.address || 'San Francisco, CA'}
          </span>
        </div>
      </section>

      {/* Location & Map Preview Bento Card */}
      <section className="bg-white rounded-xl shadow-sm overflow-hidden flex flex-col border border-[#0b1f3a]/5">
        <div className="relative w-full h-36 bg-[#eff4ff] overflow-hidden">
          {/* Stylized Vector Map Backdrop with Minimal Grid */}
          <svg
            className="absolute inset-0 w-full h-full opacity-70"
            fill="none"
            preserveAspectRatio="xMidYMid slice"
            viewBox="0 0 360 144"
            xmlns="http://www.w3.org/2000/svg"
          >
            <rect fill="#eff4ff" height="144" width="360" />
            <path d="M-10 20 L370 20" stroke="#d3e4fe" strokeWidth="6" />
            <path d="M-10 65 L370 65" stroke="#d3e4fe" strokeWidth="12" />
            <path d="M-10 120 L370 120" stroke="#d3e4fe" strokeWidth="4" />
            <path d="M50 -10 L100 154" stroke="#ffffff" strokeWidth="8" />
            <path d="M190 -10 L170 154" stroke="#ffffff" strokeWidth="14" />
            <path d="M290 -10 L320 154" stroke="#ffffff" strokeWidth="6" />
            <path d="M120 40 L260 40" stroke="#b5c7ea" strokeDasharray="4 4" strokeWidth="2" />
          </svg>

          {/* Interactive Radial Pulse & Teal Pin Marker */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="relative flex items-center justify-center">
              <span className="absolute w-12 h-12 rounded-full bg-[#4fdbc8]/40 animate-ping" />
              <div className="relative w-10 h-10 rounded-full bg-[#006b5f] shadow-lg flex items-center justify-center text-white">
                <span
                  className="material-symbols-outlined text-[22px]"
                  style={{ fontVariationSettings: "'FILL' 1" }}
                >
                  location_on
                </span>
              </div>
            </div>
          </div>

          {/* Merchant Overlay Capsule */}
          <div className="absolute bottom-2 left-3 bg-white/95 backdrop-blur-md px-3 py-1.5 rounded-lg shadow-sm flex items-center gap-2 border border-[#0b1f3a]/5">
            <span className="w-2 h-2 rounded-full bg-[#006b5f]" />
            <span className="text-[13px] font-semibold text-[#0b1c30]">
              {transaction.merchant} • {transaction.branch || 'Branch'}
            </span>
          </div>

          <div className="absolute top-2 right-3">
            <button
              onClick={() => onShowToast(`Opening Google Maps navigation to ${transaction.address || transaction.merchant}...`)}
              className="px-2.5 py-1 rounded-full bg-white/90 backdrop-blur-md shadow-sm text-[11px] font-semibold text-[#0b1c30] flex items-center gap-1 active:scale-95 transition-transform border border-[#0b1f3a]/5"
            >
              <span className="material-symbols-outlined text-[14px]">directions</span>
              <span>Open Maps</span>
            </button>
          </div>
        </div>

        {/* Location Footer Stats */}
        <div className="px-4 py-3 flex items-center justify-between bg-white">
          <div className="flex items-center gap-2 text-[#44474d]">
            <span className="material-symbols-outlined text-[18px]">storefront</span>
            <span className="text-[13px]">{transaction.terminal || 'In-store terminal #4'}</span>
          </div>
          <span className="text-[11px] font-semibold text-[#006b5f]">
            {transaction.posType || 'POS Chip Read'}
          </span>
        </div>
      </section>

      {/* Micro-Feedback Pill */}
      <div className="w-full bg-[#eff4ff] rounded-xl p-3 flex items-center justify-between border border-[#0b1f3a]/5">
        <div className="flex items-center gap-2.5">
          <span className="material-symbols-outlined text-[#006b5f] text-[20px]">
            sentiment_satisfied
          </span>
          <span className="text-[13px] text-[#0b1c30]">Was this expense recognized?</span>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={() => {
              setIsRecognized(true);
              onShowToast('Feedback saved. Thank you for securing Nova Bank.');
            }}
            aria-label="Yes, recognized"
            className={`w-8 h-8 rounded-full shadow-sm flex items-center justify-center active:scale-90 transition-transform ${
              isRecognized === true
                ? 'bg-[#006b5f] text-white'
                : 'bg-white text-[#44474d] hover:bg-[#eff4ff]'
            }`}
          >
            <span className="material-symbols-outlined text-[16px]">thumb_up</span>
          </button>
          <button
            onClick={() => {
              setIsRecognized(false);
              onShowToast('Flagged for verification. Our 24/7 fraud guard has been notified.');
            }}
            aria-label="No, unfamiliar"
            className={`w-8 h-8 rounded-full shadow-sm flex items-center justify-center active:scale-90 transition-transform ${
              isRecognized === false
                ? 'bg-[#ba1a1a] text-white'
                : 'bg-white text-[#75777e] hover:bg-[#eff4ff]'
            }`}
          >
            <span className="material-symbols-outlined text-[16px]">thumb_down</span>
          </button>
        </div>
      </div>

      {/* Primary & Destructive Action Section */}
      <div className="flex flex-col gap-2.5 mt-1">
        <button
          onClick={handleDownloadReceipt}
          disabled={isDownloading}
          className="w-full h-12 rounded-xl bg-white shadow-sm text-[#0b1c30] text-[15px] font-semibold flex items-center justify-center gap-2 active:bg-[#eff4ff] transition-colors border border-[#0b1f3a]/5"
        >
          {isDownloading ? (
            <span className="flex items-center gap-2">
              <span className="inline-block w-4 h-4 border-2 border-[#006b5f]/30 border-t-[#006b5f] rounded-full animate-spin" />
              <span>Preparing Verified PDF...</span>
            </span>
          ) : (
            <>
              <span className="material-symbols-outlined text-[20px] text-[#006b5f]">
                receipt_long
              </span>
              <span>Download Receipt (PDF)</span>
            </>
          )}
        </button>

        <button
          onClick={() => onShowToast('Opened dispute case #DP-44910. A Nova Specialist is reviewing.')}
          className="w-full h-11 rounded-xl text-[#ba1a1a] text-[13px] font-semibold flex items-center justify-center gap-2 hover:bg-[#ffdad6]/40 transition-colors"
        >
          <span className="material-symbols-outlined text-[18px]">flag</span>
          <span>Report a problem</span>
        </button>
      </div>
    </div>
  );
};
