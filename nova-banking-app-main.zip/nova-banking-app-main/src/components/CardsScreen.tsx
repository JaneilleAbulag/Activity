import React, { useState } from 'react';
import { CardInfo, Transaction } from '../types';

interface CardsScreenProps {
  cards: CardInfo[];
  transactions: Transaction[];
  onSelectTransaction: (tx: Transaction) => void;
  onShowToast: (msg: string) => void;
  onOpenAddCard: () => void;
}

export const CardsScreen: React.FC<CardsScreenProps> = ({
  cards,
  transactions,
  onSelectTransaction,
  onShowToast,
  onOpenAddCard,
}) => {
  const [activeCardIndex, setActiveCardIndex] = useState(0);
  const [isFrozen, setIsFrozen] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const [spendingLimit, setSpendingLimit] = useState(3500);
  const [spendingUsed, setSpendingUsed] = useState(2000);
  const [isEditingLimit, setIsEditingLimit] = useState(false);
  const [pinModalOpen, setPinModalOpen] = useState(false);
  const [newPin, setNewPin] = useState('');

  const currentCard = cards[activeCardIndex] || cards[0];
  const spendingPct = Math.min(100, Math.round((spendingUsed / spendingLimit) * 100));
  const remaining = Math.max(0, spendingLimit - spendingUsed);

  // Card specific transactions
  const cardTransactions = transactions.filter(
    (tx) => tx.categoryType !== 'income'
  ).slice(0, 4);

  const toggleFreeze = () => {
    const nextState = !isFrozen;
    setIsFrozen(nextState);
    onShowToast(
      nextState
        ? 'Card frozen. Online payments and in-store taps are locked.'
        : 'Card unfrozen and ready for transactions.'
    );
  };

  const handleSavePin = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPin.length === 4) {
      setPinModalOpen(false);
      setNewPin('');
      onShowToast('Card PIN updated successfully with Secure Core.');
    }
  };

  return (
    <div className="flex flex-col w-full px-4 space-y-6 pb-24 select-none max-w-md mx-auto">
      {/* Top Section Title with Action */}
      <div className="flex items-center justify-between pt-1">
        <div className="flex flex-col">
          <span className="text-[28px] font-semibold leading-[34px] tracking-[-0.015em] text-[#0b1c30]">
            My Cards
          </span>
          <span className="text-[13px] text-[#44474d]">
            Active Virtual &amp; Physical Cards
          </span>
        </div>
        <button
          onClick={onOpenAddCard}
          aria-label="Add new card"
          className="w-11 h-11 rounded-full bg-white shadow-sm flex items-center justify-center text-[#0b1f3a] active:scale-95 transition-transform duration-150 border border-[#0b1f3a]/5 hover:bg-[#eff4ff]"
        >
          <span className="material-symbols-outlined text-[24px]">add</span>
        </button>
      </div>

      {/* Card Carousel / Visual Card Display */}
      <div className="flex flex-col items-center w-full">
        {/* Premium Realistic Card */}
        <div
          className="w-full aspect-[1.586] rounded-xl p-5 flex flex-col justify-between relative overflow-hidden shadow-xl text-white transition-all duration-300 border border-white/10"
          style={{
            background:
              activeCardIndex === 0
                ? 'linear-gradient(135deg, #0B1F3A 0%, #0F3254 52%, #14B8A6 100%)'
                : 'linear-gradient(135deg, #1e293b 0%, #334155 50%, #475569 100%)',
          }}
        >
          {/* Specular Shimmer Layer */}
          <div className="absolute -inset-full bg-gradient-to-tr from-transparent via-white/10 to-transparent rotate-12 pointer-events-none" />

          {/* Top Row: Bank Badge & Contactless */}
          <div className="flex items-center justify-between relative z-10">
            <div className="flex items-center space-x-2">
              <div className="w-6 h-6 rounded-md bg-white/20 backdrop-blur-md flex items-center justify-center">
                <span className="material-symbols-outlined text-white text-[16px]">account_balance</span>
              </div>
              <span className="text-[17px] font-semibold tracking-tight text-white/95">
                {currentCard.bankName}
              </span>
              <span className="px-1.5 py-0.5 rounded-full bg-white/15 text-[9px] font-semibold tracking-wider uppercase backdrop-blur-sm text-white/80">
                {currentCard.type}
              </span>
            </div>
            <div className="flex items-center space-x-2 text-white/80">
              <span className="material-symbols-outlined text-[22px] rotate-90">contactless</span>
            </div>
          </div>

          {/* Center: EMV Chip & Monospace Card Number */}
          <div className="relative z-10 flex flex-col space-y-3 my-auto pt-1">
            <div className="w-10 h-7 rounded bg-gradient-to-br from-amber-200 via-amber-400 to-amber-600 shadow-inner flex items-center justify-center relative overflow-hidden opacity-95">
              <div className="w-full h-[1px] bg-black/25 absolute top-2" />
              <div className="w-full h-[1px] bg-black/25 absolute bottom-2" />
              <div className="h-full w-[1px] bg-black/25 absolute left-3" />
              <div className="h-full w-[1px] bg-black/25 absolute right-3" />
            </div>

            <div className="flex items-center justify-between tracking-widest font-mono text-[17px] font-semibold text-white/95 drop-shadow-sm">
              <span>{showDetails ? '5412' : '••••'}</span>
              <span>{showDetails ? '7590' : '••••'}</span>
              <span>{showDetails ? '3821' : '••••'}</span>
              <span className="tracking-normal">{currentCard.lastFour}</span>
            </div>
          </div>

          {/* Bottom Row: Cardholder, Expiry, CVV & Network Emblem */}
          <div className="flex items-end justify-between relative z-10 text-white/90">
            <div className="flex space-x-5">
              <div className="flex flex-col">
                <span className="text-[10px] text-white/60 tracking-wider uppercase font-semibold">
                  Cardholder
                </span>
                <span className="text-[13px] tracking-wider font-semibold text-white">
                  {currentCard.cardholder}
                </span>
              </div>
              <div className="flex flex-col">
                <span className="text-[10px] text-white/60 tracking-wider uppercase font-semibold">
                  Expires
                </span>
                <span className="text-[13px] font-semibold text-white">
                  {currentCard.expires}
                </span>
              </div>
              <div className="flex flex-col">
                <span className="text-[10px] text-white/60 tracking-wider uppercase font-semibold">
                  CVV
                </span>
                <span className="text-[13px] font-semibold text-white">
                  {showDetails ? currentCard.cvv : '•••'}
                </span>
              </div>
            </div>

            {/* Dual Circle Network Emblem */}
            <div className="flex items-center -space-x-2.5 opacity-90">
              <div className="w-6 h-6 rounded-full bg-red-500/90 mix-blend-screen shadow-sm" />
              <div className="w-6 h-6 rounded-full bg-amber-400/90 mix-blend-screen shadow-sm" />
            </div>
          </div>

          {/* Frozen State Overlay */}
          <div
            className={`absolute inset-0 bg-[#0b1f3a]/85 backdrop-blur-sm z-20 flex flex-col items-center justify-center space-y-2 transition-opacity duration-300 ${
              isFrozen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
            }`}
          >
            <div className="w-12 h-12 rounded-full bg-[#6df5e1]/20 flex items-center justify-center">
              <span className="material-symbols-outlined text-[#71f8e4] text-[28px]">ac_unit</span>
            </div>
            <span className="text-[17px] font-semibold text-white">Card is Frozen</span>
            <span className="text-[13px] text-white/70">Tap toggle below to unfreeze</span>
          </div>
        </div>

        {/* Swipe Pagination Indicator */}
        <div className="flex items-center justify-center space-x-1.5 mt-4">
          {cards.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setActiveCardIndex(idx)}
              className={`rounded-full transition-all ${
                activeCardIndex === idx
                  ? 'w-6 h-1.5 bg-[#006b5f]'
                  : 'w-1.5 h-1.5 bg-[#dce9ff]'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Quick Action Round Buttons */}
      <div className="grid grid-cols-4 gap-3 w-full">
        <button
          onClick={toggleFreeze}
          className="flex flex-col items-center group active:scale-95 transition-transform"
        >
          <div
            className={`w-14 h-14 rounded-full shadow-sm flex items-center justify-center transition-colors border border-[#0b1f3a]/5 ${
              isFrozen
                ? 'bg-[#006b5f] text-white'
                : 'bg-white text-[#000615] group-hover:bg-[#eff4ff]'
            }`}
          >
            <span className="material-symbols-outlined text-[24px]">
              {isFrozen ? 'lock_open' : 'ac_unit'}
            </span>
          </div>
          <span className="text-[11px] font-semibold text-[#0b1c30] mt-2">
            {isFrozen ? 'Unfreeze' : 'Freeze'}
          </span>
        </button>

        <button
          onClick={() => {
            setShowDetails(!showDetails);
            onShowToast(
              showDetails
                ? 'Card numbers hidden for security.'
                : 'Full card number and CVV revealed.'
            );
          }}
          className="flex flex-col items-center group active:scale-95 transition-transform"
        >
          <div className="w-14 h-14 rounded-full bg-white shadow-sm flex items-center justify-center text-[#000615] group-hover:bg-[#eff4ff] transition-colors border border-[#0b1f3a]/5">
            <span className="material-symbols-outlined text-[24px]">
              {showDetails ? 'visibility_off' : 'visibility'}
            </span>
          </div>
          <span className="text-[11px] font-semibold text-[#0b1c30] mt-2">Details</span>
        </button>

        <button
          onClick={() => setPinModalOpen(true)}
          className="flex flex-col items-center group active:scale-95 transition-transform"
        >
          <div className="w-14 h-14 rounded-full bg-white shadow-sm flex items-center justify-center text-[#000615] group-hover:bg-[#eff4ff] transition-colors border border-[#0b1f3a]/5">
            <span className="material-symbols-outlined text-[24px]">dialpad</span>
          </div>
          <span className="text-[11px] font-semibold text-[#0b1c30] mt-2">Change PIN</span>
        </button>

        <button
          onClick={() => onShowToast('Card settings: Online transactions & international limits active.')}
          className="flex flex-col items-center group active:scale-95 transition-transform"
        >
          <div className="w-14 h-14 rounded-full bg-white shadow-sm flex items-center justify-center text-[#000615] group-hover:bg-[#eff4ff] transition-colors border border-[#0b1f3a]/5">
            <span className="material-symbols-outlined text-[24px]">tune</span>
          </div>
          <span className="text-[11px] font-semibold text-[#0b1c30] mt-2">Settings</span>
        </button>
      </div>

      {/* Freeze Card Toggle Card */}
      <div className="w-full bg-white rounded-xl p-4 shadow-sm flex items-center justify-between space-x-3 border border-[#0b1f3a]/5">
        <div className="flex items-center space-x-3.5 min-w-0">
          <div className="w-10 h-10 rounded-full bg-[#eff4ff] flex items-center justify-center text-[#000615] shrink-0">
            <span className="material-symbols-outlined text-[22px]">lock</span>
          </div>
          <div className="flex flex-col min-w-0">
            <span className="text-[17px] font-semibold text-[#0b1c30] truncate">
              Freeze card
            </span>
            <span className="text-[13px] text-[#44474d] line-clamp-2">
              Instantly block all card transactions and online payments
            </span>
          </div>
        </div>

        <div className="shrink-0 flex items-center">
          <button
            onClick={toggleFreeze}
            role="switch"
            aria-checked={isFrozen}
            className={`w-[51px] h-[31px] rounded-full relative transition-colors duration-200 flex items-center px-0.5 focus:outline-none ${
              isFrozen ? 'bg-[#006b5f]' : 'bg-[#dce9ff]'
            }`}
          >
            <span
              className={`w-[27px] h-[27px] rounded-full bg-white shadow-md transform transition-transform duration-200 ${
                isFrozen ? 'translate-x-[20px]' : 'translate-x-0'
              }`}
            />
          </button>
        </div>
      </div>

      {/* Monthly Spending Limit Card */}
      <div className="w-full bg-white rounded-xl p-4 shadow-sm flex flex-col space-y-3 border border-[#0b1f3a]/5">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className="material-symbols-outlined text-[#006b5f] text-[20px]">speed</span>
            <span className="text-[13px] font-semibold text-[#0b1c30]">Monthly spending limit</span>
          </div>
          <button
            onClick={() => setIsEditingLimit(!isEditingLimit)}
            className="text-[11px] font-semibold text-[#006b5f] hover:underline"
          >
            {isEditingLimit ? 'Done' : 'Edit Limit'}
          </button>
        </div>

        <div className="flex items-baseline justify-between pt-0.5">
          <span className="text-[22px] font-semibold text-[#0b1c30]">
            ${spendingUsed.toLocaleString()}{' '}
            <span className="text-[13px] text-[#44474d] font-normal">
              of ${spendingLimit.toLocaleString()} used
            </span>
          </span>
          <span className="text-[13px] font-semibold text-[#44474d]">{spendingPct}%</span>
        </div>

        {/* Progress Slider */}
        {isEditingLimit ? (
          <div className="flex flex-col space-y-1 py-1">
            <input
              type="range"
              min="2000"
              max="10000"
              step="250"
              value={spendingLimit}
              onChange={(e) => setSpendingLimit(Number(e.target.value))}
              className="w-full accent-[#006b5f] cursor-pointer"
            />
            <span className="text-[11px] text-[#44474d]">
              Adjust monthly safety threshold: ${spendingLimit.toLocaleString()}
            </span>
          </div>
        ) : (
          <div className="relative w-full h-3 bg-[#eff4ff] rounded-full flex items-center overflow-visible">
            <div
              className="h-full bg-[#006b5f] rounded-full transition-all duration-300"
              style={{ width: `${spendingPct}%` }}
            />
            <div
              className="absolute w-5 h-5 rounded-full bg-white shadow-md border-2 border-[#006b5f] transition-all duration-300"
              style={{ left: `calc(${spendingPct}% - 10px)` }}
            />
          </div>
        )}

        <div className="flex items-center justify-between pt-1 text-[#44474d]">
          <span className="text-[13px] flex items-center space-x-1">
            <span className="material-symbols-outlined text-[16px] text-[#006b5f]">check_circle</span>
            <span>${remaining.toLocaleString()} remaining this month</span>
          </span>
          <span className="text-[11px] font-semibold">Resets Nov 1</span>
        </div>
      </div>

      {/* Recent Card Transactions */}
      <div className="flex flex-col space-y-2.5 pb-2">
        <div className="flex items-center justify-between px-1">
          <span className="text-[17px] font-semibold text-[#0b1c30]">Recent card transactions</span>
          <button
            onClick={() => onShowToast('Showing all card debit entries.')}
            className="text-[13px] font-semibold text-[#006b5f] hover:underline"
          >
            View all
          </button>
        </div>

        <div className="bg-white rounded-xl shadow-sm overflow-hidden flex flex-col border border-[#0b1f3a]/5 divide-y divide-[#e5eeff]">
          {cardTransactions.map((tx) => (
            <div
              key={tx.id}
              onClick={() => onSelectTransaction(tx)}
              className="flex items-center justify-between p-4 active:bg-[#eff4ff] hover:bg-[#eff4ff]/60 transition-colors cursor-pointer"
            >
              <div className="flex items-center space-x-3 min-w-0">
                <div
                  className={`w-10 h-10 rounded-xl ${tx.iconBg} flex items-center justify-center ${tx.iconColor} shrink-0`}
                >
                  <span className="material-symbols-outlined text-[22px]">
                    {tx.iconName}
                  </span>
                </div>
                <div className="flex flex-col min-w-0">
                  <span className="text-[15px] font-semibold text-[#0b1c30] truncate">
                    {tx.merchant}
                  </span>
                  <span className="text-[13px] text-[#44474d] truncate">
                    {tx.subCategory || tx.category} • {tx.date}
                  </span>
                </div>
              </div>
              <div className="text-right shrink-0">
                <span className="text-[15px] font-semibold text-[#0b1c30]">
                  -${tx.amount.toFixed(2)}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* PIN Change Modal */}
      {pinModalOpen && (
        <div className="fixed inset-0 z-50 bg-[#0b1f3a]/50 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-5 w-full max-w-sm shadow-xl flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <h3 className="text-[17px] font-semibold text-[#0b1c30]">Change Card PIN</h3>
              <button
                onClick={() => setPinModalOpen(false)}
                className="w-8 h-8 rounded-full flex items-center justify-center text-[#44474d] hover:bg-[#eff4ff]"
              >
                <span className="material-symbols-outlined text-[20px]">close</span>
              </button>
            </div>
            <p className="text-[13px] text-[#44474d]">
              Enter a new 4-digit PIN for your Nova Debit card •••• {currentCard.lastFour}.
            </p>
            <form onSubmit={handleSavePin} className="flex flex-col gap-4">
              <input
                type="password"
                maxLength={4}
                autoFocus
                value={newPin}
                onChange={(e) => setNewPin(e.target.value.replace(/\D/g, ''))}
                placeholder="••••"
                className="text-center text-3xl font-mono tracking-widest h-14 bg-[#eff4ff] rounded-xl outline-none focus:ring-2 focus:ring-[#006b5f]"
              />
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setPinModalOpen(false)}
                  className="flex-1 h-11 bg-[#eff4ff] rounded-xl text-[13px] font-semibold text-[#44474d]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={newPin.length !== 4}
                  className="flex-1 h-11 bg-[#0b1f3a] text-white rounded-xl text-[13px] font-semibold disabled:opacity-50"
                >
                  Save PIN
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
