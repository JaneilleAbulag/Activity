import React, { useState } from 'react';

interface TopUpModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTopUp: (amount: number, source: string) => void;
}

export const TopUpModal: React.FC<TopUpModalProps> = ({
  isOpen,
  onClose,
  onTopUp,
}) => {
  const [amount, setAmount] = useState('250.00');
  const [source, setSource] = useState('Chase Checking (•••• 8192)');
  const [isProcessing, setIsProcessing] = useState(false);

  if (!isOpen) return null;

  const quickAmounts = [50, 100, 250, 500];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const num = parseFloat(amount);
    if (isNaN(num) || num <= 0) return;

    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      onTopUp(num, source);
      onClose();
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#0b1f3a]/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-white rounded-t-3xl sm:rounded-2xl w-full max-w-md p-6 shadow-2xl flex flex-col gap-4 animate-in slide-in-from-bottom duration-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-full bg-[#6df5e1]/30 flex items-center justify-center text-[#006b5f]">
              <span className="material-symbols-outlined text-[20px]">add_circle</span>
            </div>
            <h3 className="text-[17px] font-semibold text-[#0b1c30]">Top Up Account</h3>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-[#44474d] hover:bg-[#eff4ff]"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div className="flex flex-col gap-1">
            <label className="text-[11px] font-semibold text-[#44474d]">From Source</label>
            <select
              value={source}
              onChange={(e) => setSource(e.target.value)}
              className="h-12 px-3 rounded-xl bg-[#eff4ff] text-[15px] font-medium outline-none focus:ring-2 focus:ring-[#006b5f]/30"
            >
              <option value="Chase Checking (•••• 8192)">Chase Checking (•••• 8192)</option>
              <option value="Vanguard Cash Reserves">Vanguard Cash Reserves</option>
              <option value="Apple Pay Instant Deposit">Apple Pay Instant Deposit</option>
              <option value="FedNow Real-Time Transfer">FedNow Real-Time Transfer</option>
            </select>
          </div>

          <div className="flex flex-col gap-1">
            <label className="text-[11px] font-semibold text-[#44474d]">Amount ($)</label>
            <div className="relative flex items-center">
              <span className="absolute left-4 text-2xl font-bold text-[#0b1c30]">$</span>
              <input
                type="number"
                step="0.01"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full h-14 pl-9 pr-4 rounded-xl bg-[#eff4ff] text-3xl font-bold text-[#0b1c30] outline-none focus:ring-2 focus:ring-[#006b5f]/30 font-['Inter']"
                placeholder="0.00"
                required
              />
            </div>

            <div className="flex gap-2 mt-2">
              {quickAmounts.map((q) => (
                <button
                  key={q}
                  type="button"
                  onClick={() => setAmount(q.toFixed(2))}
                  className="flex-1 py-1.5 rounded-lg bg-[#eff4ff] hover:bg-[#dce9ff] text-[13px] font-semibold text-[#0b1c30]"
                >
                  +${q}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2 p-3 bg-[#eff4ff] rounded-xl text-[13px] text-[#44474d]">
            <span className="material-symbols-outlined text-[18px] text-[#006b5f]">bolt</span>
            <span>Zero fees. Available instantly in your checking balance.</span>
          </div>

          <button
            type="submit"
            disabled={isProcessing}
            className="w-full h-13 bg-[#006b5f] hover:bg-[#005048] text-white rounded-xl text-[15px] font-semibold shadow-sm flex items-center justify-center gap-2 mt-2 disabled:opacity-50 active:scale-[0.99] transition-all"
          >
            {isProcessing ? (
              <span className="flex items-center gap-2">
                <span className="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Transferring funds...
              </span>
            ) : (
              <>
                <span>Confirm Deposit</span>
                <span className="material-symbols-outlined text-[18px]">check</span>
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};
