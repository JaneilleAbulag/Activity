import React from 'react';
import { ScreenType } from '../types';

interface BottomNavProps {
  currentScreen: ScreenType;
  onNavigate: (screen: ScreenType) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ currentScreen, onNavigate }) => {
  if (currentScreen === 'login') {
    return null;
  }

  const tabs: { key: ScreenType; label: string; icon: string }[] = [
    { key: 'home', label: 'Home', icon: 'home' },
    { key: 'cards', label: 'Cards', icon: 'credit_card' },
    { key: 'payments', label: 'Payments', icon: 'swap_horiz' },
    { key: 'insights', label: 'Insights', icon: 'pie_chart' },
    { key: 'profile', label: 'Profile', icon: 'person' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#f8f9ff]/90 backdrop-blur-xl shadow-[0_-1px_12px_rgba(0,0,0,0.04)] border-t border-[#0b1f3a]/5">
      <div className="max-w-md mx-auto flex justify-around items-center h-16 px-2">
        {tabs.map((tab) => {
          const isActive =
            currentScreen === tab.key ||
            (tab.key === 'home' && currentScreen === 'transaction-detail');

          return (
            <button
              key={tab.key}
              onClick={() => onNavigate(tab.key)}
              aria-current={isActive ? 'page' : undefined}
              className={`flex flex-col items-center justify-center min-w-[56px] min-h-[44px] transition-all select-none active:scale-95 ${
                isActive
                  ? 'text-[#006b5f] font-semibold'
                  : 'text-[#44474d] hover:text-[#0b1c30]'
              }`}
            >
              <span
                className="material-symbols-outlined text-[24px]"
                style={isActive ? { fontVariationSettings: "'FILL' 1" } : undefined}
              >
                {tab.icon}
              </span>
              <span className="text-[11px] leading-[14px] mt-0.5 tracking-[0.02em]">
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>

      {/* iOS Home Indicator */}
      <div className="flex justify-center pb-2 pt-1">
        <div className="w-32 h-1 bg-[#0b1c30]/20 rounded-full" />
      </div>
    </nav>
  );
};
