import React, { useState } from 'react';
import { Transaction, UserProfile } from '../types';
import { WEEKLY_SPENDING } from '../data/mockData';

interface HomeScreenProps {
  user: UserProfile;
  balance: number;
  transactions: Transaction[];
  onSelectTransaction: (transaction: Transaction) => void;
  onNavigateToPayments: () => void;
  onOpenSend: () => void;
  onOpenRequest: () => void;
  onOpenTopUp: () => void;
  onOpenNotifications: () => void;
  onShowToast: (msg: string) => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  user,
  balance,
  transactions,
  onSelectTransaction,
  onNavigateToPayments,
  onOpenSend,
  onOpenRequest,
  onOpenTopUp,
  onOpenNotifications,
  onShowToast,
}) => {
  const [hideBalance, setHideBalance] = useState(false);
  const [selectedDay, setSelectedDay] = useState<string>('Fri');
  const [showAllTransactions, setShowAllTransactions] = useState(false);

  const displayTransactions = showAllTransactions
    ? transactions
    : transactions.slice(0, 5);

  const handleCopyAccount = () => {
    navigator.clipboard?.writeText('4821098412344821').catch(() => {});
    onShowToast('Account number •••• 4821 copied to clipboard');
  };

  return (
    <div className="flex flex-col w-full px-4 pb-24 space-y-6 max-w-md mx-auto select-none">
      {/* Greeting Bar */}
      <section className="flex items-center justify-between pt-1">
        <div className="flex items-center space-x-3">
          <div className="relative w-12 h-12 rounded-full overflow-hidden shadow-sm bg-[#dce9ff] flex-shrink-0 ring-2 ring-[#006b5f]/20">
            <img
              alt={user.name}
              className="w-full h-full object-cover"
              src={user.avatarUrl}
            />
          </div>
          <div className="flex flex-col">
            <span className="text-[13px] text-[#44474d] leading-[18px]">Good morning,</span>
            <span className="text-[22px] text-[#0b1f3a] font-semibold tracking-tight leading-[28px]">
              {user.firstName}
            </span>
          </div>
        </div>

        <div className="relative">
          <button
            onClick={onOpenNotifications}
            aria-label="Notifications"
            className="w-11 h-11 rounded-full bg-white shadow-sm flex items-center justify-center text-[#0b1f3a] hover:bg-[#eff4ff] transition-colors active:scale-95 duration-150 border border-[#0b1f3a]/5"
          >
            <span className="material-symbols-outlined text-[24px]">notifications</span>
          </button>
          <span className="absolute top-2 right-2 w-2.5 h-2.5 bg-[#ba1a1a] rounded-full pointer-events-none ring-2 ring-[#f8f9ff]" />
        </div>
      </section>

      {/* Total Balance Bento Card */}
      <section
        className="relative overflow-hidden rounded-xl shadow-md p-4 text-white"
        style={{
          background: 'linear-gradient(135deg, #0B1F3A 0%, #11365F 58%, #14B8A6 100%)',
        }}
      >
        {/* Ambient organic backdrop decor */}
        <div className="absolute -right-12 -top-12 w-48 h-48 rounded-full bg-[#6df5e1]/15 blur-2xl pointer-events-none" />
        <div className="absolute -left-12 -bottom-12 w-40 h-40 rounded-full bg-black/30 blur-xl pointer-events-none" />

        <div className="relative z-10 flex flex-col space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <span className="text-[13px] font-semibold tracking-wide text-white/80">
                Total Balance
              </span>
              <button
                onClick={() => setHideBalance(!hideBalance)}
                aria-label="Toggle balance visibility"
                className="w-8 h-8 rounded-full flex items-center justify-center text-white/70 hover:text-white transition-colors active:scale-90"
              >
                <span className="material-symbols-outlined text-[18px]">
                  {hideBalance ? 'visibility_off' : 'visibility'}
                </span>
              </button>
            </div>

            <div className="flex items-center space-x-1.5 bg-white/10 backdrop-blur-md px-2.5 py-1 rounded-full">
              <span className="material-symbols-outlined text-[14px] text-[#6df5e1]">
                trending_up
              </span>
              <span className="text-[11px] font-semibold text-[#6df5e1]">
                +3.4% this month
              </span>
            </div>
          </div>

          <div className="flex items-baseline space-x-1">
            <span className="text-[40px] font-bold leading-[48px] tracking-tight text-white font-['Inter']">
              {hideBalance
                ? '••••••••'
                : `$${balance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}
            </span>
          </div>

          <div className="flex items-center justify-between pt-1">
            <div className="flex items-center space-x-2 bg-black/20 backdrop-blur-sm px-2.5 py-1 rounded-lg">
              <span className="text-[13px] text-white/90 tracking-widest font-mono">
                •••• 4821
              </span>
              <button
                onClick={handleCopyAccount}
                className="w-7 h-7 flex items-center justify-center text-white/70 hover:text-white active:scale-90 transition-transform"
                title="Copy account number"
              >
                <span className="material-symbols-outlined text-[16px]">content_copy</span>
              </button>
            </div>

            <div className="flex items-center space-x-1">
              <div className="w-3.5 h-3.5 rounded-full bg-[#6df5e1]/80" />
              <div className="w-3.5 h-3.5 rounded-full bg-white/40 -ml-2" />
            </div>
          </div>
        </div>
      </section>

      {/* Quick Actions Row */}
      <section className="grid grid-cols-4 gap-2">
        <div className="flex flex-col items-center">
          <button
            onClick={onOpenSend}
            className="w-14 h-14 rounded-full bg-[#eff4ff] hover:bg-[#e5eeff] text-[#0b1f3a] shadow-sm flex items-center justify-center active:scale-95 transition-all border border-[#0b1f3a]/5"
          >
            <span className="material-symbols-outlined text-[24px]">send</span>
          </button>
          <span className="text-[11px] font-semibold text-[#0b1c30] mt-2 text-center">
            Send
          </span>
        </div>

        <div className="flex flex-col items-center">
          <button
            onClick={onOpenRequest}
            className="w-14 h-14 rounded-full bg-[#eff4ff] hover:bg-[#e5eeff] text-[#0b1f3a] shadow-sm flex items-center justify-center active:scale-95 transition-all border border-[#0b1f3a]/5"
          >
            <span className="material-symbols-outlined text-[24px]">call_received</span>
          </button>
          <span className="text-[11px] font-semibold text-[#0b1c30] mt-2 text-center">
            Request
          </span>
        </div>

        <div className="flex flex-col items-center">
          <button
            onClick={onNavigateToPayments}
            className="w-14 h-14 rounded-full bg-[#eff4ff] hover:bg-[#e5eeff] text-[#0b1f3a] shadow-sm flex items-center justify-center active:scale-95 transition-all border border-[#0b1f3a]/5"
          >
            <span className="material-symbols-outlined text-[24px]">receipt_long</span>
          </button>
          <span className="text-[11px] font-semibold text-[#0b1c30] mt-2 text-center">
            Pay Bills
          </span>
        </div>

        <div className="flex flex-col items-center">
          <button
            onClick={onOpenTopUp}
            className="w-14 h-14 rounded-full bg-[#eff4ff] hover:bg-[#e5eeff] text-[#0b1f3a] shadow-sm flex items-center justify-center active:scale-95 transition-all border border-[#0b1f3a]/5"
          >
            <span className="material-symbols-outlined text-[24px]">add_circle</span>
          </button>
          <span className="text-[11px] font-semibold text-[#0b1c30] mt-2 text-center">
            Top Up
          </span>
        </div>
      </section>

      {/* Spending Overview Card */}
      <section className="bg-white rounded-xl p-4 shadow-sm flex flex-col space-y-4 border border-[#0b1f3a]/5">
        <div className="flex items-center justify-between">
          <div className="flex flex-col">
            <span className="text-[15px] font-semibold text-[#0b1f3a]">Spending overview</span>
            <span className="text-[13px] text-[#44474d]">
              You spent <strong className="text-[#0b1c30] font-semibold">$420</strong> this week
            </span>
          </div>
          <div className="bg-[#eff4ff] px-2.5 py-1 rounded-full">
            <span className="text-[11px] text-[#006b5f] font-semibold">82% of budget</span>
          </div>
        </div>

        {/* Weekly Pill Bar Chart */}
        <div className="flex items-end justify-between h-28 pt-4 px-1">
          {WEEKLY_SPENDING.map((item) => {
            const isSelected = selectedDay === item.day;
            const isFridayPeak = item.isPeak;

            return (
              <div
                key={item.day}
                onClick={() => {
                  setSelectedDay(item.day);
                  onShowToast(`${item.day}: $${item.amount} spent`);
                }}
                className="flex flex-col items-center space-y-2 group cursor-pointer relative"
              >
                {/* Floating pill badge for Friday peak or active day */}
                {(isFridayPeak || isSelected) && (
                  <span
                    className={`absolute -top-5 text-[10px] font-bold tracking-tight px-1.5 py-0.5 rounded-full transition-all ${
                      isFridayPeak
                        ? 'text-[#006b5f] bg-[#6df5e1]/30'
                        : 'text-[#0b1f3a] bg-[#eff4ff]'
                    }`}
                  >
                    ${item.amount}
                  </span>
                )}

                <div
                  className={`w-7 h-20 rounded-full flex flex-col justify-end p-0.5 overflow-hidden transition-all ${
                    isFridayPeak
                      ? 'bg-[#6df5e1]/20'
                      : isSelected
                      ? 'bg-[#dce9ff]'
                      : 'bg-[#eff4ff]'
                  }`}
                >
                  <div
                    className={`w-full rounded-full transition-all duration-300 ${
                      isFridayPeak
                        ? 'bg-[#006b5f] shadow-sm'
                        : isSelected
                        ? 'bg-[#0b1f3a]'
                        : 'bg-[#dce9ff] group-hover:bg-[#0b1f3a]'
                    }`}
                    style={{ height: `${item.heightPct}%` }}
                  />
                </div>

                <span
                  className={`text-[11px] font-semibold ${
                    isFridayPeak
                      ? 'text-[#006b5f]'
                      : isSelected
                      ? 'text-[#0b1c30]'
                      : 'text-[#44474d]'
                  }`}
                >
                  {item.day}
                </span>
              </div>
            );
          })}
        </div>
      </section>

      {/* Recent Transactions Section */}
      <section className="flex flex-col space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-[17px] font-semibold text-[#0b1f3a]">Recent Transactions</h2>
          <button
            onClick={() => setShowAllTransactions(!showAllTransactions)}
            className="min-h-[44px] flex items-center text-[13px] font-semibold text-[#006b5f] hover:underline transition-colors"
          >
            {showAllTransactions ? 'Show less' : 'See all'}
          </button>
        </div>

        {/* Transaction List Container */}
        <div className="bg-white rounded-xl shadow-sm overflow-hidden flex flex-col border border-[#0b1f3a]/5 divide-y divide-[#e5eeff]">
          {displayTransactions.map((tx) => (
            <div
              key={tx.id}
              onClick={() => onSelectTransaction(tx)}
              className="flex items-center justify-between p-3.5 hover:bg-[#eff4ff]/60 active:bg-[#eff4ff] transition-colors cursor-pointer"
            >
              <div className="flex items-center space-x-3 min-w-0">
                <div
                  className={`w-12 h-12 rounded-xl ${tx.iconBg} flex items-center justify-center ${tx.iconColor} flex-shrink-0`}
                >
                  <span className="material-symbols-outlined text-[22px]">
                    {tx.iconName}
                  </span>
                </div>
                <div className="flex flex-col min-w-0">
                  <span className="text-[15px] font-semibold text-[#0b1f3a] truncate">
                    {tx.merchant}
                  </span>
                  <span className="text-[13px] text-[#44474d] truncate">
                    {tx.category} • {tx.date}
                  </span>
                </div>
              </div>

              <div className="text-right flex-shrink-0 ml-3">
                <span
                  className={`text-[15px] font-semibold ${
                    tx.type === 'credit' ? 'text-[#006b5f] font-bold' : 'text-[#0b1c30]'
                  }`}
                >
                  {tx.type === 'credit' ? '+' : '-'}${tx.amount.toFixed(2)}
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
