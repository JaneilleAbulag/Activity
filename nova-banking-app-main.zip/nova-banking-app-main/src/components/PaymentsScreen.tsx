import React, { useState } from 'react';
import { UpcomingBill } from '../types';

interface PaymentsScreenProps {
  bills: UpcomingBill[];
  onPayBill: (billId: string) => void;
  onShowToast: (msg: string) => void;
}

export const PaymentsScreen: React.FC<PaymentsScreenProps> = ({
  bills,
  onPayBill,
  onShowToast,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [autoPayEnabled, setAutoPayEnabled] = useState(true);
  const [payingBillId, setPayingBillId] = useState<string | null>(null);
  const [paidBillIds, setPaidBillIds] = useState<Record<string, boolean>>({});
  const [scheduleModalOpen, setScheduleModalOpen] = useState(false);

  const categories = [
    { key: 'electricity', label: 'Electricity', icon: 'bolt' },
    { key: 'water', label: 'Water', icon: 'water_drop' },
    { key: 'internet', label: 'Internet', icon: 'wifi' },
    { key: 'mobile', label: 'Mobile', icon: 'smartphone' },
    { key: 'insurance', label: 'Insurance', icon: 'shield' },
    { key: 'credit_card', label: 'Credit Card', icon: 'credit_card' },
    { key: 'rent', label: 'Rent', icon: 'home' },
    { key: 'more', label: 'More', icon: 'apps' },
  ];

  const filteredBills = bills.filter((b) => {
    const matchesSearch =
      b.biller.toLowerCase().includes(searchQuery.toLowerCase()) ||
      b.accountSuffix.includes(searchQuery) ||
      b.category.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory =
      !activeCategory ||
      b.category.toLowerCase() === activeCategory.toLowerCase();
    return matchesSearch && matchesCategory;
  });

  const handlePay = (bill: UpcomingBill) => {
    if (paidBillIds[bill.id]) return;
    setPayingBillId(bill.id);

    setTimeout(() => {
      setPayingBillId(null);
      setPaidBillIds((prev) => ({ ...prev, [bill.id]: true }));
      onPayBill(bill.id);
      onShowToast(`$${bill.amount.toFixed(2)} paid to ${bill.biller}`);
    }, 850);
  };

  const handleCategoryClick = (catKey: string) => {
    if (activeCategory === catKey) {
      setActiveCategory(null);
      onShowToast('Cleared category filter.');
    } else {
      setActiveCategory(catKey);
      onShowToast(`Filtered by ${catKey.replace('_', ' ')}`);
    }
  };

  const pendingCount = bills.filter((b) => !paidBillIds[b.id]).length;

  return (
    <div className="flex flex-col w-full px-4 space-y-6 pb-24 select-none max-w-md mx-auto">
      {/* Search and Screen Title Bar */}
      <div className="flex flex-col gap-2 pt-1">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h2 className="text-[28px] font-semibold text-[#0b1c30] tracking-tight leading-[34px]">
              Payments
            </h2>
            <span className="inline-flex items-center px-2 py-0.5 rounded-full bg-[#6df5e1]/30 text-[#006b5f] text-[11px] font-semibold">
              Bill Pay
            </span>
          </div>

          <button
            onClick={() => onShowToast('Past bill payment receipts (14 records verified).')}
            aria-label="Transaction History"
            className="w-11 h-11 rounded-xl bg-white shadow-sm flex items-center justify-center text-[#44474d] hover:text-[#0b1f3a] active:scale-95 transition-all border border-[#0b1f3a]/5"
          >
            <span className="material-symbols-outlined text-[20px]">receipt_long</span>
          </button>
        </div>

        {/* Search Input Container */}
        <div className="relative w-full">
          <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#75777e]">
            <span className="material-symbols-outlined text-[20px]">search</span>
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search billers, services, or account numbers"
            className="w-full h-[52px] bg-white text-[#0b1c30] placeholder:text-[#75777e] text-[15px] pl-11 pr-10 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-[#006b5f]/30 transition-all border border-[#0b1f3a]/5"
          />
          <button
            onClick={() => onShowToast('Camera scanner ready for utility invoices.')}
            aria-label="Scan barcode or QR"
            className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-[#006b5f] hover:text-[#005048] active:scale-95 transition-transform"
          >
            <span className="material-symbols-outlined text-[22px]">document_scanner</span>
          </button>
        </div>
      </div>

      {/* Category Grid: 2 rows x 4 columns */}
      <div className="flex flex-col gap-2">
        <div className="flex items-center justify-between px-0.5">
          <h3 className="text-[17px] font-semibold text-[#0b1c30]">Categories</h3>
          <button
            onClick={() => onShowToast('Category re-ordering & alerts opened.')}
            className="text-[13px] font-semibold text-[#006b5f] hover:underline"
          >
            Manage
          </button>
        </div>

        <div className="grid grid-cols-4 gap-y-4 gap-x-2 bg-white rounded-xl p-4 shadow-sm border border-[#0b1f3a]/5">
          {categories.map((cat) => {
            const isSelected = activeCategory === cat.key;
            return (
              <button
                key={cat.key}
                onClick={() => handleCategoryClick(cat.key)}
                className="flex flex-col items-center gap-1.5 group active:scale-95 transition-transform min-w-0"
              >
                <div
                  className={`w-12 h-12 rounded-full flex items-center justify-center transition-colors ${
                    isSelected
                      ? 'bg-[#006b5f] text-white'
                      : 'bg-[#eff4ff] text-[#0b1f3a] group-hover:bg-[#6df5e1]/30 group-hover:text-[#006b5f]'
                  }`}
                >
                  <span className="material-symbols-outlined text-[24px]">
                    {cat.icon}
                  </span>
                </div>
                <span
                  className={`text-[11px] font-semibold truncate w-full text-center ${
                    isSelected ? 'text-[#006b5f]' : 'text-[#44474d] group-hover:text-[#0b1c30]'
                  }`}
                >
                  {cat.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Upcoming Bills Section */}
      <div className="flex flex-col gap-2">
        <div className="flex items-center justify-between px-0.5">
          <div className="flex items-center gap-2">
            <h3 className="text-[17px] font-semibold text-[#0b1c30]">Upcoming bills</h3>
            <span className="inline-flex items-center px-2 py-0.5 rounded-full bg-[#d3e4fe] text-[#0b1c30] text-[11px] font-semibold">
              {pendingCount} pending
            </span>
          </div>

          <button
            onClick={() => onShowToast('Bills sorted by due date priority.')}
            className="text-[13px] font-semibold text-[#44474d] hover:text-[#0b1c30] transition-colors flex items-center gap-0.5"
          >
            <span>Sort</span>
            <span className="material-symbols-outlined text-[16px]">unfold_more</span>
          </button>
        </div>

        {/* Bills List Container */}
        <div className="flex flex-col gap-3">
          {filteredBills.length === 0 ? (
            <div className="bg-white rounded-xl p-8 text-center text-[#44474d] shadow-sm border border-[#0b1f3a]/5">
              No bills found matching your criteria.
            </div>
          ) : (
            filteredBills.map((bill) => {
              const isPaid = paidBillIds[bill.id];
              const isPaying = payingBillId === bill.id;

              return (
                <div
                  key={bill.id}
                  className="bg-white rounded-xl p-4 shadow-sm flex flex-col gap-3 relative overflow-hidden border border-[#0b1f3a]/5"
                >
                  {bill.isOverdue && !isPaid && (
                    <div className="absolute left-0 top-0 bottom-0 w-1 bg-[#ba1a1a]" />
                  )}

                  <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3 min-w-0">
                      <div
                        className={`w-11 h-11 rounded-xl flex-shrink-0 flex items-center justify-center ${
                          bill.isOverdue && !isPaid
                            ? 'bg-[#ffdad6]/40 text-[#ba1a1a]'
                            : 'bg-[#eff4ff] text-[#0b1f3a]'
                        }`}
                      >
                        <span className="material-symbols-outlined text-[22px]">
                          {bill.icon}
                        </span>
                      </div>
                      <div className="flex flex-col min-w-0">
                        <span className="text-[17px] font-semibold text-[#0b1c30] truncate">
                          {bill.biller}
                        </span>
                        <div className="flex items-center gap-1.5 mt-0.5">
                          {isPaid ? (
                            <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-[#6df5e1]/30 text-[#006f64] text-[11px] font-semibold">
                              <span className="material-symbols-outlined text-[12px]">check</span>
                              Paid in full
                            </span>
                          ) : bill.isOverdue ? (
                            <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-[#ffdad6] text-[#93000a] text-[11px] font-semibold">
                              <span className="material-symbols-outlined text-[12px]">warning</span>
                              {bill.dueNote}
                            </span>
                          ) : (
                            <span className="text-[13px] text-[#44474d]">
                              {bill.dueNote}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-col items-end flex-shrink-0">
                      <span className="text-[24px] font-semibold leading-[30px] text-[#0b1c30] tracking-tight">
                        ${bill.amount.toFixed(2)}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2 bg-[#eff4ff]/50 -mx-4 -mb-4 px-4 py-2.5 rounded-b-xl mt-1">
                    <div className="flex items-center gap-1.5 text-[#75777e]">
                      <span className="material-symbols-outlined text-[15px]">tag</span>
                      <span className="text-[13px] text-[#44474d]">
                        Acc •••• {bill.accountSuffix}
                      </span>
                    </div>

                    <button
                      onClick={() => handlePay(bill)}
                      disabled={isPaid || isPaying}
                      className={`min-h-[44px] px-5 rounded-xl text-[15px] font-semibold flex items-center justify-center gap-1.5 shadow-sm active:scale-95 transition-all ${
                        isPaid
                          ? 'bg-[#6df5e1] text-[#006f64] cursor-default'
                          : bill.isOverdue
                          ? 'bg-[#006b5f] hover:bg-[#005048] text-white'
                          : 'bg-[#0b1f3a] hover:bg-[#152e52] text-white'
                      }`}
                    >
                      {isPaying ? (
                        <>
                          <span className="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                          <span>Paying</span>
                        </>
                      ) : isPaid ? (
                        <>
                          <span className="material-symbols-outlined text-[18px]">check</span>
                          <span>Done</span>
                        </>
                      ) : (
                        <>
                          <span>Pay</span>
                          <span className="material-symbols-outlined text-[18px]">arrow_forward</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Scheduled Payments & Automation Card */}
      <div className="bg-white rounded-xl p-4 shadow-sm flex flex-col gap-3 border border-[#0b1f3a]/5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-11 h-11 rounded-xl bg-[#6df5e1]/20 flex-shrink-0 flex items-center justify-center text-[#006b5f]">
              <span className="material-symbols-outlined text-[24px]">event_repeat</span>
            </div>
            <div className="flex flex-col min-w-0 pr-2">
              <h4 className="text-[17px] font-semibold text-[#0b1c30] truncate">
                Scheduled payments
              </h4>
              <p className="text-[13px] text-[#44474d] mt-0.5 line-clamp-1">
                Auto-pay enabled for 4 utility accounts
              </p>
            </div>
          </div>

          <label className="relative inline-flex items-center cursor-pointer flex-shrink-0 min-w-[51px] min-h-[44px] justify-center">
            <input
              type="checkbox"
              checked={autoPayEnabled}
              onChange={() => {
                const next = !autoPayEnabled;
                setAutoPayEnabled(next);
                onShowToast(
                  next
                    ? 'Auto-pay enabled for all connected utilities.'
                    : 'Auto-pay paused. Manual confirmation required.'
                );
              }}
              className="sr-only peer"
            />
            <div className="w-[51px] h-[31px] bg-[#d3e4fe] peer-focus:outline-none rounded-full peer peer-checked:bg-[#006b5f] transition-colors duration-200" />
            <div className="absolute left-[2px] top-[8.5px] bg-white w-[27px] h-[27px] rounded-full shadow-md transition-transform duration-200 ease-in-out transform peer-checked:translate-x-[20px]" />
          </label>
        </div>

        <div className="flex items-center justify-between pt-3 mt-1 bg-white flex-wrap gap-2 border-t border-[#e5eeff]">
          <div className="flex items-center gap-2">
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#006b5f] opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-[#006b5f]" />
            </span>
            <span className="text-[11px] font-semibold text-[#44474d]">
              Next run: Oct 01 (Sprint Mobile)
            </span>
          </div>
          <button
            onClick={() => setScheduleModalOpen(true)}
            className="text-[13px] font-semibold text-[#006b5f] hover:underline py-1"
          >
            View Schedule
          </button>
        </div>
      </div>

      {/* Schedule Modal */}
      {scheduleModalOpen && (
        <div className="fixed inset-0 z-50 bg-[#0b1f3a]/50 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-5 w-full max-w-sm shadow-xl flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <h3 className="text-[17px] font-semibold text-[#0b1c30]">Auto-Pay Schedule</h3>
              <button
                onClick={() => setScheduleModalOpen(false)}
                className="w-8 h-8 rounded-full flex items-center justify-center text-[#44474d] hover:bg-[#eff4ff]"
              >
                <span className="material-symbols-outlined text-[20px]">close</span>
              </button>
            </div>
            <div className="flex flex-col divide-y divide-[#e5eeff] text-[13px]">
              <div className="py-2.5 flex justify-between">
                <span className="font-semibold text-[#0b1c30]">Sprint Mobile</span>
                <span className="text-[#006b5f] font-semibold">Oct 01 • $65.00</span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="font-semibold text-[#0b1c30]">PG&amp;E Electricity</span>
                <span className="text-[#006b5f] font-semibold">Oct 28 • $142.80</span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="font-semibold text-[#0b1c30]">Metro Water District</span>
                <span className="text-[#006b5f] font-semibold">Nov 12 • $45.20</span>
              </div>
            </div>
            <button
              onClick={() => setScheduleModalOpen(false)}
              className="w-full h-11 bg-[#0b1f3a] text-white rounded-xl text-[13px] font-semibold mt-2"
            >
              Done
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
