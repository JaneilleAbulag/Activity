import React, { useState } from 'react';
import { CardInfo } from '../types';

interface AddCardModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddCard: (card: CardInfo) => void;
}

export const AddCardModal: React.FC<AddCardModalProps> = ({
  isOpen,
  onClose,
  onAddCard,
}) => {
  const [type, setType] = useState<'virtual' | 'physical'>('virtual');
  const [name, setName] = useState('Nova Bank Travel Edition');
  const [limit, setLimit] = useState('2500');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newCard: CardInfo = {
      id: `card-${Date.now()}`,
      type,
      bankName: name || 'Nova Bank Virtual',
      lastFour: Math.floor(1000 + Math.random() * 9000).toString(),
      cardholder: 'ALEX MORGAN',
      expires: '10/29',
      cvv: Math.floor(100 + Math.random() * 900).toString(),
      isFrozen: false,
      spendingUsed: 0,
      spendingLimit: parseFloat(limit) || 2500,
    };
    onAddCard(newCard);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#0b1f3a]/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-white rounded-t-3xl sm:rounded-2xl w-full max-w-md p-6 shadow-2xl flex flex-col gap-4 animate-in slide-in-from-bottom duration-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-full bg-[#eff4ff] flex items-center justify-center text-[#0b1f3a]">
              <span className="material-symbols-outlined text-[20px]">add_card</span>
            </div>
            <h3 className="text-[17px] font-semibold text-[#0b1c30]">Issue New Card</h3>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-[#44474d] hover:bg-[#eff4ff]"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div className="flex flex-col gap-1">
            <label className="text-[11px] font-semibold text-[#44474d]">Card Type</label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setType('virtual')}
                className={`py-2.5 rounded-xl text-[13px] font-semibold flex items-center justify-center gap-1.5 border transition-all ${
                  type === 'virtual'
                    ? 'border-[#006b5f] bg-[#6df5e1]/10 text-[#006b5f]'
                    : 'border-[#0b1f3a]/10 text-[#44474d]'
                }`}
              >
                <span className="material-symbols-outlined text-[18px]">phone_iphone</span>
                <span>Virtual Card</span>
              </button>
              <button
                type="button"
                onClick={() => setType('physical')}
                className={`py-2.5 rounded-xl text-[13px] font-semibold flex items-center justify-center gap-1.5 border transition-all ${
                  type === 'physical'
                    ? 'border-[#006b5f] bg-[#6df5e1]/10 text-[#006b5f]'
                    : 'border-[#0b1f3a]/10 text-[#44474d]'
                }`}
              >
                <span className="material-symbols-outlined text-[18px]">credit_card</span>
                <span>Metal Physical</span>
              </button>
            </div>
          </div>

          <div className="flex flex-col gap-1">
            <label className="text-[11px] font-semibold text-[#44474d]">Card Label</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="h-11 px-3 rounded-xl bg-[#eff4ff] text-[13px] outline-none"
              placeholder="e.g. Travel, Online Subscriptions"
              required
            />
          </div>

          <div className="flex flex-col gap-1">
            <label className="text-[11px] font-semibold text-[#44474d]">Monthly Spend Cap ($)</label>
            <input
              type="number"
              value={limit}
              onChange={(e) => setLimit(e.target.value)}
              className="h-11 px-3 rounded-xl bg-[#eff4ff] text-[13px] outline-none"
              placeholder="2500"
              required
            />
          </div>

          <button
            type="submit"
            className="w-full h-12 bg-[#0b1f3a] text-white rounded-xl text-[15px] font-semibold flex items-center justify-center gap-2 mt-2"
          >
            <span>Create Card Instantly</span>
            <span className="material-symbols-outlined text-[18px]">arrow_forward</span>
          </button>
        </form>
      </div>
    </div>
  );
};
