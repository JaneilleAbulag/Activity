import React, { useState } from 'react';
import { UserProfile } from '../types';

interface ProfileScreenProps {
  user: UserProfile;
  onLogout: () => void;
  onShowToast: (msg: string) => void;
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  user,
  onLogout,
  onShowToast,
}) => {
  const [darkMode, setDarkMode] = useState(false);
  const [biometricEnabled, setBiometricEnabled] = useState(true);
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState(user.name);
  const [email, setEmail] = useState(user.email);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    setIsEditing(false);
    onShowToast('Profile information updated.');
  };

  return (
    <div className="flex flex-col w-full px-4 pb-24 gap-6 select-none max-w-md mx-auto">
      {/* Profile Header Card */}
      <section className="flex flex-col items-center text-center p-6 bg-white rounded-2xl shadow-sm relative overflow-hidden border border-[#0b1f3a]/5">
        <div className="absolute -top-12 -right-12 w-32 h-32 bg-[#6df5e1]/20 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute -bottom-10 -left-10 w-28 h-28 bg-[#e5eeff]/60 rounded-full blur-xl pointer-events-none" />

        {/* Avatar Container */}
        <div className="relative mb-3">
          <div className="w-20 h-20 rounded-full p-1 bg-gradient-to-tr from-[#006b5f] to-[#6df5e1] flex items-center justify-center shadow-sm">
            <img
              alt={user.name}
              className="w-full h-full rounded-full object-cover"
              src={user.avatarUrl}
            />
          </div>
          <div
            className="absolute -bottom-0.5 -right-0.5 w-6 h-6 rounded-full bg-[#006b5f] text-white flex items-center justify-center shadow-sm"
            title="Verified Account"
          >
            <span
              className="material-symbols-outlined text-[14px]"
              style={{ fontVariationSettings: "'FILL' 1" }}
            >
              verified
            </span>
          </div>
        </div>

        {/* User Identity Details */}
        <h2 className="text-[22px] font-semibold text-[#000615] tracking-tight">
          {name}
        </h2>
        <p className="text-[13px] text-[#44474d] mt-0.5">{email}</p>

        {/* Tier / Plan Badge */}
        <div className="inline-flex items-center gap-1.5 px-3 py-1 mt-2.5 rounded-full bg-[#6df5e1]/30 text-[#006f64] text-[11px] font-semibold">
          <span
            className="material-symbols-outlined text-[14px] text-[#006b5f]"
            style={{ fontVariationSettings: "'FILL' 1" }}
          >
            stars
          </span>
          <span>{user.tier}</span>
        </div>

        {/* Edit Profile Action */}
        <button
          type="button"
          onClick={() => setIsEditing(!isEditing)}
          className="mt-4 px-5 h-10 min-h-[40px] rounded-full bg-[#eff4ff] hover:bg-[#e5eeff] text-[#0b1f3a] text-[13px] font-semibold flex items-center justify-center gap-1.5 active:scale-95 transition-transform duration-150 border border-[#0b1f3a]/5"
        >
          <span className="material-symbols-outlined text-[18px]">edit</span>
          <span>{isEditing ? 'Cancel' : 'Edit profile'}</span>
        </button>

        {isEditing && (
          <form onSubmit={handleSaveProfile} className="w-full mt-4 flex flex-col gap-2 pt-2 border-t border-[#e5eeff]">
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full h-10 px-3 rounded-lg bg-[#eff4ff] text-[13px] outline-none"
              placeholder="Full Name"
            />
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full h-10 px-3 rounded-lg bg-[#eff4ff] text-[13px] outline-none"
              placeholder="Email address"
            />
            <button
              type="submit"
              className="w-full h-10 bg-[#0b1f3a] text-white rounded-lg text-[13px] font-semibold"
            >
              Save Changes
            </button>
          </form>
        )}
      </section>

      {/* Group 1: Account & Security */}
      <section className="flex flex-col gap-1.5">
        <div className="px-2 text-[11px] font-semibold text-[#44474d] uppercase tracking-wider">
          Account &amp; Security
        </div>
        <div className="flex flex-col bg-white rounded-2xl shadow-sm overflow-hidden border border-[#0b1f3a]/5 divide-y divide-[#e5eeff]">
          {/* Item: Personal Information */}
          <button
            type="button"
            onClick={() => onShowToast('Personal Information: SSN, Address & ID verified.')}
            className="w-full min-h-[56px] px-4 py-3 flex items-center justify-between text-left active:bg-[#eff4ff] hover:bg-[#eff4ff]/50 transition-colors"
          >
            <div className="flex items-center gap-3.5 min-w-0">
              <div className="w-9 h-9 rounded-xl bg-[#eff4ff] flex items-center justify-center text-[#0b1f3a] shrink-0">
                <span className="material-symbols-outlined text-[20px]">person</span>
              </div>
              <span className="text-[15px] font-semibold text-[#0b1c30] truncate">
                Personal Information
              </span>
            </div>
            <span className="material-symbols-outlined text-[#c4c6ce] text-[20px] shrink-0 ml-2">
              chevron_right
            </span>
          </button>

          {/* Item: Security */}
          <button
            type="button"
            onClick={() => onShowToast('Security Health: 100%. Hardware enclave active.')}
            className="w-full min-h-[56px] px-4 py-3 flex items-center justify-between text-left active:bg-[#eff4ff] hover:bg-[#eff4ff]/50 transition-colors"
          >
            <div className="flex items-center gap-3.5 min-w-0">
              <div className="w-9 h-9 rounded-xl bg-[#eff4ff] flex items-center justify-center text-[#0b1f3a] shrink-0">
                <span className="material-symbols-outlined text-[20px]">shield_person</span>
              </div>
              <div className="flex flex-col min-w-0 truncate">
                <span className="text-[15px] font-semibold text-[#0b1c30] truncate">
                  Security
                </span>
                <span className="text-[13px] text-[#44474d] truncate">
                  Face ID, PIN, 2FA enabled
                </span>
              </div>
            </div>
            <span className="material-symbols-outlined text-[#c4c6ce] text-[20px] shrink-0 ml-2">
              chevron_right
            </span>
          </button>

          {/* Item: Linked Accounts */}
          <button
            type="button"
            onClick={() => onShowToast('Linked Accounts: Chase Checking, Vanguard IRA.')}
            className="w-full min-h-[56px] px-4 py-3 flex items-center justify-between text-left active:bg-[#eff4ff] hover:bg-[#eff4ff]/50 transition-colors"
          >
            <div className="flex items-center gap-3.5 min-w-0">
              <div className="w-9 h-9 rounded-xl bg-[#eff4ff] flex items-center justify-center text-[#0b1f3a] shrink-0">
                <span className="material-symbols-outlined text-[20px]">account_balance</span>
              </div>
              <div className="flex flex-col min-w-0 truncate">
                <span className="text-[15px] font-semibold text-[#0b1c30] truncate">
                  Linked Accounts
                </span>
                <span className="text-[13px] text-[#44474d] truncate">
                  {user.accountsConnected} accounts connected
                </span>
              </div>
            </div>
            <span className="material-symbols-outlined text-[#c4c6ce] text-[20px] shrink-0 ml-2">
              chevron_right
            </span>
          </button>

          {/* Item: Spending & Transfer Limits */}
          <button
            type="button"
            onClick={() => onShowToast('Daily limit: $10,000. Wire limit: $50,000.')}
            className="w-full min-h-[56px] px-4 py-3 flex items-center justify-between text-left active:bg-[#eff4ff] hover:bg-[#eff4ff]/50 transition-colors"
          >
            <div className="flex items-center gap-3.5 min-w-0">
              <div className="w-9 h-9 rounded-xl bg-[#eff4ff] flex items-center justify-center text-[#0b1f3a] shrink-0">
                <span className="material-symbols-outlined text-[20px]">tune</span>
              </div>
              <span className="text-[15px] font-semibold text-[#0b1c30] truncate">
                Spending &amp; Transfer Limits
              </span>
            </div>
            <span className="material-symbols-outlined text-[#c4c6ce] text-[20px] shrink-0 ml-2">
              chevron_right
            </span>
          </button>
        </div>
      </section>

      {/* Group 2: Preferences */}
      <section className="flex flex-col gap-1.5">
        <div className="px-2 text-[11px] font-semibold text-[#44474d] uppercase tracking-wider">
          Preferences
        </div>
        <div className="flex flex-col bg-white rounded-2xl shadow-sm overflow-hidden border border-[#0b1f3a]/5 divide-y divide-[#e5eeff]">
          {/* Item: Notifications */}
          <button
            type="button"
            onClick={() => {
              setNotificationsEnabled(!notificationsEnabled);
              onShowToast(notificationsEnabled ? 'Push notifications muted.' : 'Instant transaction push notifications enabled.');
            }}
            className="w-full min-h-[56px] px-4 py-3 flex items-center justify-between text-left active:bg-[#eff4ff] hover:bg-[#eff4ff]/50 transition-colors"
          >
            <div className="flex items-center gap-3.5 min-w-0">
              <div className="w-9 h-9 rounded-xl bg-[#eff4ff] flex items-center justify-center text-[#0b1f3a] shrink-0">
                <span className="material-symbols-outlined text-[20px]">notifications</span>
              </div>
              <span className="text-[15px] font-semibold text-[#0b1c30] truncate">
                Notifications
              </span>
            </div>
            <span className="material-symbols-outlined text-[#c4c6ce] text-[20px] shrink-0 ml-2">
              chevron_right
            </span>
          </button>

          {/* Item: Language */}
          <button
            type="button"
            onClick={() => onShowToast('Current language: English (US)')}
            className="w-full min-h-[56px] px-4 py-3 flex items-center justify-between text-left active:bg-[#eff4ff] hover:bg-[#eff4ff]/50 transition-colors"
          >
            <div className="flex items-center gap-3.5 min-w-0">
              <div className="w-9 h-9 rounded-xl bg-[#eff4ff] flex items-center justify-center text-[#0b1f3a] shrink-0">
                <span className="material-symbols-outlined text-[20px]">language</span>
              </div>
              <div className="flex flex-col min-w-0 truncate">
                <span className="text-[15px] font-semibold text-[#0b1c30] truncate">
                  Language
                </span>
                <span className="text-[13px] text-[#44474d] truncate">
                  English (US)
                </span>
              </div>
            </div>
            <span className="material-symbols-outlined text-[#c4c6ce] text-[20px] shrink-0 ml-2">
              chevron_right
            </span>
          </button>

          {/* Item: Dark Mode Toggle */}
          <div className="w-full min-h-[56px] px-4 py-3 flex items-center justify-between">
            <div className="flex items-center gap-3.5 min-w-0">
              <div className="w-9 h-9 rounded-xl bg-[#eff4ff] flex items-center justify-center text-[#0b1f3a] shrink-0">
                <span className="material-symbols-outlined text-[20px]">dark_mode</span>
              </div>
              <span className="text-[15px] font-semibold text-[#0b1c30] truncate">
                Dark mode
              </span>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={darkMode}
              onClick={() => {
                const next = !darkMode;
                setDarkMode(next);
                onShowToast(next ? 'Dark mode activated.' : 'Light mode activated.');
              }}
              className={`w-[51px] h-[31px] rounded-full p-0.5 relative transition-colors duration-200 focus:outline-none shrink-0 ${
                darkMode ? 'bg-[#006b5f]' : 'bg-[#dce9ff]'
              }`}
            >
              <div
                className={`w-[27px] h-[27px] bg-white rounded-full shadow-sm transform transition-transform duration-200 ease-in-out ${
                  darkMode ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Item: Biometric Login Toggle */}
          <div className="w-full min-h-[56px] px-4 py-3 flex items-center justify-between">
            <div className="flex items-center gap-3.5 min-w-0">
              <div className="w-9 h-9 rounded-xl bg-[#eff4ff] flex items-center justify-center text-[#0b1f3a] shrink-0">
                <span className="material-symbols-outlined text-[20px]">face</span>
              </div>
              <span className="text-[15px] font-semibold text-[#0b1c30] truncate">
                Biometric login
              </span>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={biometricEnabled}
              onClick={() => {
                const next = !biometricEnabled;
                setBiometricEnabled(next);
                onShowToast(
                  next
                    ? 'Face ID / Fingerprint enabled for instant login.'
                    : 'Biometric login disabled. Passcode required.'
                );
              }}
              className={`w-[51px] h-[31px] rounded-full p-0.5 relative transition-colors duration-200 focus:outline-none shrink-0 ${
                biometricEnabled ? 'bg-[#006b5f]' : 'bg-[#dce9ff]'
              }`}
            >
              <div
                className={`w-[27px] h-[27px] bg-white rounded-full shadow-sm transform transition-transform duration-200 ease-in-out ${
                  biometricEnabled ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>
        </div>
      </section>

      {/* Group 3: Support */}
      <section className="flex flex-col gap-1.5">
        <div className="px-2 text-[11px] font-semibold text-[#44474d] uppercase tracking-wider">
          Support
        </div>
        <div className="flex flex-col bg-white rounded-2xl shadow-sm overflow-hidden border border-[#0b1f3a]/5 divide-y divide-[#e5eeff]">
          <button
            type="button"
            onClick={() => onShowToast('Nova 24/7 Concierge: Live chat initiated.')}
            className="w-full min-h-[56px] px-4 py-3 flex items-center justify-between text-left active:bg-[#eff4ff] hover:bg-[#eff4ff]/50 transition-colors"
          >
            <div className="flex items-center gap-3.5 min-w-0">
              <div className="w-9 h-9 rounded-xl bg-[#eff4ff] flex items-center justify-center text-[#0b1f3a] shrink-0">
                <span className="material-symbols-outlined text-[20px]">support_agent</span>
              </div>
              <span className="text-[15px] font-semibold text-[#0b1c30] truncate">
                Help &amp; Support
              </span>
            </div>
            <span className="material-symbols-outlined text-[#c4c6ce] text-[20px] shrink-0 ml-2">
              chevron_right
            </span>
          </button>

          <button
            type="button"
            onClick={() => onShowToast('FDIC Insured up to $250,000. Privacy policy v4.2.')}
            className="w-full min-h-[56px] px-4 py-3 flex items-center justify-between text-left active:bg-[#eff4ff] hover:bg-[#eff4ff]/50 transition-colors"
          >
            <div className="flex items-center gap-3.5 min-w-0">
              <div className="w-9 h-9 rounded-xl bg-[#eff4ff] flex items-center justify-center text-[#0b1f3a] shrink-0">
                <span className="material-symbols-outlined text-[20px]">description</span>
              </div>
              <span className="text-[15px] font-semibold text-[#0b1c30] truncate">
                Privacy Policy &amp; Legal
              </span>
            </div>
            <span className="material-symbols-outlined text-[#c4c6ce] text-[20px] shrink-0 ml-2">
              chevron_right
            </span>
          </button>
        </div>
      </section>

      {/* Logout Action & App Version Metadata */}
      <section className="flex flex-col gap-2 pt-2">
        <button
          type="button"
          onClick={onLogout}
          className="w-full h-12 min-h-[48px] rounded-2xl bg-[#ffdad6]/40 text-[#ba1a1a] text-[15px] font-semibold flex items-center justify-center gap-2 active:bg-[#ffdad6]/70 active:scale-[0.99] transition-all cursor-pointer"
        >
          <span className="material-symbols-outlined text-[20px]">logout</span>
          <span>Log out</span>
        </button>
        <p className="text-center text-[11px] text-[#75777e] tracking-tight mt-1">
          Nova Bank iOS v4.2.0 • Build 8921
        </p>
      </section>
    </div>
  );
};
