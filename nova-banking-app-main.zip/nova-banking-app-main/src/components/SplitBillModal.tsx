import React, { useState } from 'react';
import { Transaction } from '../types';

interface SplitBillModalProps {
  isOpen: boolean;
  onClose: () => void;
  transaction: Transaction | null;
  onConfirmSplit: (amountPerPerson: number, count: number) => void;
}

export const SplitBillModal: React.FC<SplitBillModalProps> = ({
  isOpen,
  onClose,
  transaction,
  onConfirmSplit,
}) => {
  const [splitCount, setSplitCount] = useState(2);
  const [includeTip, setIncludeTip] = useState(false);

  if (!isOpen || !transaction) return null;

  const total = includeTip ? transaction.amount * 1.18 : transaction.amount;
  const perPerson = total / splitCount;

  return (
    <div className="fixed inset-0 z-50 bg-[#0b1f3a]/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-white rounded-t-3xl sm:rounded-2xl w-full max-w-md p-6 shadow-2xl flex flex-col gap-4 animate-in slide-in-from-bottom duration-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-full bg-[#eff4ff] flex items-center justify-center text-[#0b1f3a]">
              <span className="material-symbols-outlined text-[20px]">call_split</span>
            </div>
            <h3 className="text-[17px] font-semibold text-[#0b1c30]">Split Bill</h3>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-[#44474d] hover:bg-[#eff4ff]"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        <div className="p-4 bg-[#eff4ff] rounded-2xl flex flex-col items-center text-center">
          <span className="text-[13px] text-[#44474d]">{transaction.merchant}</span>
          <span className="text-[32px] font-bold text-[#0b1c30] tracking-tight">
            ${perPerson.toFixed(2)}
          </span>
          <span className="text-[11px] font-semibold text-[#006b5f] mt-0.5">
            Per person (split among {splitCount} people)
          </span>
        </div>

        {/* Split count picker */}
        <div className="flex flex-col gap-2">
          <span className="text-[11px] font-semibold text-[#44474d] uppercase tracking-wider">
            Number of People
          </span>
          <div className="grid grid-cols-4 gap-2">
            {[2, 3, 4, 5].map((num) => (
              <button
                key={num}
                type="button"
                onClick={() => setSplitCount(num)}
                className={`py-3 rounded-xl font-semibold text-[15px] transition-all ${
                  splitCount === num
                    ? 'bg-[#0b1f3a] text-white shadow-sm'
                    : 'bg-[#eff4ff] text-[#0b1c30] hover:bg-[#dce9ff]'
                }`}
              >
                {num} people
              </button>
            ))}
          </div>
        </div>

        {/* Optional 18% Tip */}
        <div className="flex items-center justify-between p-3 rounded-xl bg-[#eff4ff]">
          <span className="text-[13px] text-[#0b1c30] font-medium">Add 18% standard gratuity</span>
          <input
            type="checkbox"
            checked={includeTip}
            onChange={() => setIncludeTip(!includeTip)}
            className="w-5 h-5 accent-[#006b5f] cursor-pointer"
          />
        </div>

        <button
          onClick={() => {
            onConfirmSplit(perPerson, splitCount);
            onClose();
          }}
          className="w-full h-12 bg-[#006b5f] hover:bg-[#005048] text-white rounded-xl text-[15px] font-semibold flex items-center justify-center gap-2 mt-2 active:scale-[0.99] transition-all"
        >
          <span className="material-symbols-outlined text-[18px]">send</span>
          <span>Send Payment Requests</span>
        </button>
      </div>
    </div>
  );
};
